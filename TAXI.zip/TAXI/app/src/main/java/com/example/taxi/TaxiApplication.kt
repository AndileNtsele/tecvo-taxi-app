package com.example.taxi

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.android.gms.maps.model.LatLng

class TaxiApplication : Application() {
    // References to the notification service
    private var mapNotificationService: MapNotificationService? = null
    private var lastKnownLocation: LatLng? = null
    private var currentUserId: String? = null

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this) // Initialize Firebase

        // Load background notification preference
        val sharedPrefs = getSharedPreferences("taxi_app_prefs", MODE_PRIVATE)
        val allowBackgroundNotifications = sharedPrefs.getBoolean("allow_background_notifications", false)

        // Initialize NotificationManager with background preference
        NotificationManager.setAllowBackgroundNotifications(allowBackgroundNotifications)

        // Initialize the notification service here but don't start monitoring yet
        mapNotificationService = MapNotificationService(applicationContext)
        Log.d("TaxiApplication", "Application created, notification service initialized")
        Log.d("TaxiApplication", "Background notifications set to: $allowBackgroundNotifications")
    }

    // Method to initialize the notification service
    fun initNotificationService(userId: String, location: LatLng) {
        Log.d("TaxiApplication", "Starting notification service for user: $userId")

        // Store these for later updates
        currentUserId = userId
        lastKnownLocation = location

        // Start monitoring with initial preferences
        mapNotificationService?.startMonitoring(userId, location)
    }

    // Method to update user location in the notification service
    fun updateUserLocation(location: LatLng) {
        lastKnownLocation = location
        mapNotificationService?.updateUserLocation(location)
    }

    // Method to update notification preferences
    fun updateNotificationServicePreferences() {
        // Only update if the service is running and we have the necessary data
        if (mapNotificationService != null && currentUserId != null && lastKnownLocation != null) {
            mapNotificationService?.updateNotificationPreferences()
        }
    }

    // Method to cleanup when app is closing
    fun cleanupNotificationService() {
        mapNotificationService?.cleanup()
        mapNotificationService = null
        Log.d("TaxiApplication", "Notification service cleaned up")
    }

    // Method for status checking
    fun isNotificationServiceInitialized(): Boolean {
        return mapNotificationService != null
    }
}