package com.example.taxi

import android.util.Log

/**
 * Singleton class to manage application-wide notification state
 * This class tracks whether notifications should be active based on the current screen
 */
object NotificationManager {
    private const val TAG = "NotificationManager"

    // Track whether the user is currently in a map screen
    private var isInMapScreen = false

    // Flag to control whether notifications should be shown when app is in background
    private var allowBackgroundNotifications = false

    /**
     * Call this when user enters a map screen
     * @param screenName Name of the map screen for logging purposes
     */
    fun enterMapScreen(screenName: String) {
        Log.d(TAG, "User entered map screen: $screenName")
        isInMapScreen = true
    }

    /**
     * Call this when user leaves a map screen
     * @param screenName Name of the map screen for logging purposes
     */
    fun exitMapScreen(screenName: String) {
        Log.d(TAG, "User exited map screen: $screenName")
        isInMapScreen = false
    }

    /**
     * Sets whether notifications should be displayed when the app is not showing a map
     * @param allow Whether to allow background notifications
     */
    fun setAllowBackgroundNotifications(allow: Boolean) {
        Log.d(TAG, "Background notifications set to: $allow")
        allowBackgroundNotifications = allow
    }

    /**
     * Checks whether notifications should be displayed based on current state
     * @return true if notifications should be displayed, false otherwise
     */
    fun shouldShowNotifications(): Boolean {
        // Always show notifications if user is in a map screen
        if (isInMapScreen) {
            return true
        }

        // Only show notifications when not in map if user has explicitly allowed it
        return allowBackgroundNotifications
    }
}