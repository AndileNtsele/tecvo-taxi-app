package com.example.taxi

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.*
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import com.example.taxi.NotificationManager as AppNotificationManager

class MapNotificationService(private val context: Context) {

    private val TAG = "MapNotificationService"
    private val database = Firebase.database("https://taxiapp-8aecb-default-rtdb.firebaseio.com/")

    // Updated to match the nested structure in Firebase
    private val driversRef = database.getReference("drivers/town")
    private val passengersRef = database.getReference("passengers/town")

    private val sharedPrefs = context.getSharedPreferences("taxi_app_prefs", Context.MODE_PRIVATE)

    private val CHANNEL_ID = "taxi_app_channel"
    private val PASSENGER_NOTIFICATION_ID = 1001
    private val DRIVER_NOTIFICATION_ID = 1002
    private val NOTIFICATION_PERMISSION_REQUEST_CODE = 1234

    // Increased default radius to 50km (50000m)
    private val DEFAULT_NOTIFICATION_RADIUS_KM = 50.0f
    private val DEFAULT_NOTIFICATION_RADIUS_METERS = (DEFAULT_NOTIFICATION_RADIUS_KM * 1000).toInt()

    private var passengerListener: ValueEventListener? = null
    private var driverListener: ValueEventListener? = null

    // Update these tracking data structures to remember all users and their proximity status
    private val knownPassengers = mutableMapOf<String, Boolean>() // Maps ID to "already notified" status
    private val knownDrivers = mutableMapOf<String, Boolean>()

    private var currentUserLocation: LatLng? = null
    private var userId: String? = null

    private var notificationJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    // Added initialization flag to ensure preferences are properly set
    private var isInitialized = false

    init {
        createNotificationChannel()

        // Set default notification preferences to true if they haven't been set yet
        if (!sharedPrefs.contains("notify_passengers")) {
            sharedPrefs.edit().putBoolean("notify_passengers", true).apply()
            Log.d(TAG, "Setting default notify_passengers preference to true")
        }

        if (!sharedPrefs.contains("notify_drivers")) {
            sharedPrefs.edit().putBoolean("notify_drivers", true).apply()
            Log.d(TAG, "Setting default notify_drivers preference to true")
        }

        // Set default notification radius if not set
        if (!sharedPrefs.contains("notification_radius_km")) {
            sharedPrefs.edit().putFloat("notification_radius_km", DEFAULT_NOTIFICATION_RADIUS_KM).apply()
            Log.d(TAG, "Setting default notification radius to $DEFAULT_NOTIFICATION_RADIUS_KM km")
        }

        // Set default background notification preference if not set
        if (!sharedPrefs.contains("allow_background_notifications")) {
            sharedPrefs.edit().putBoolean("allow_background_notifications", false).apply()
            Log.d(TAG, "Setting default background notifications to false")
        }

        // Initialize the notification manager with user's background notification preference
        val allowBackgroundNotifications = sharedPrefs.getBoolean("allow_background_notifications", false)
        AppNotificationManager.setAllowBackgroundNotifications(allowBackgroundNotifications)
    }

    /**
     * Checks if notification permission is granted
     * @return true if permission is granted, false otherwise
     */
    fun hasNotificationPermission(): Boolean {
        val hasPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true // For versions below Android 13, we don't need explicit permission
        }

        Log.d(TAG, "Notification permission check: $hasPermission")
        return hasPermission
    }

    /**
     * Request notification permission if it's not already granted
     * @param activity The activity context to request permissions from
     * @return true if permission is already granted or not needed, false if request was made
     */
    fun requestNotificationPermissionIfNeeded(activity: Activity): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!hasNotificationPermission()) {
                Log.d(TAG, "Requesting notification permission")
                ActivityCompat.requestPermissions(
                    activity,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    NOTIFICATION_PERMISSION_REQUEST_CODE
                )
                return false  // Permission request is now pending
            }
        }
        return true  // Permission is granted or not needed
    }

    /**
     * Shows an explanation dialog when notification permission is denied
     * @param activity The activity context to show the dialog in
     */
    fun showNotificationPermissionExplanationDialog(activity: Activity) {
        AlertDialog.Builder(activity)
            .setTitle("Notification Permission Required")
            .setMessage("To receive alerts about nearby drivers and passengers, please enable notifications for this app. Without this permission, you won't be notified when taxis are nearby.")
            .setPositiveButton("Enable Notifications") { _, _ ->
                // Open app settings
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package", activity.packageName, null)
                intent.data = uri
                activity.startActivity(intent)
            }
            .setNegativeButton("Not Now") { dialog, _ ->
                dialog.dismiss()
                showPermissionDeniedToast(activity)
            }
            .setCancelable(false)
            .create()
            .show()
    }

    /**
     * Shows a toast message explaining the consequences of denying the permission
     */
    private fun showPermissionDeniedToast(activity: Activity) {
        android.widget.Toast.makeText(
            activity,
            "You won't receive notifications when taxis are nearby. You can enable notifications later in app settings.",
            android.widget.Toast.LENGTH_LONG
        ).show()
    }

    fun startMonitoring(userId: String, initialLocation: LatLng) {
        this.userId = userId
        this.currentUserLocation = initialLocation

        // Log service startup info
        Log.d(TAG, "Starting monitoring for user: $userId at location: ${initialLocation.latitude}, ${initialLocation.longitude}")
        Log.d(TAG, "Notification permission status: ${hasNotificationPermission()}")

        // Get the current user's location from Firebase to ensure we have the correct coordinates
        val userRef = database.getReference("passengers/town/$userId")
        userRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val lat = snapshot.child("latitude").getValue(Double::class.java)
                val lng = snapshot.child("longitude").getValue(Double::class.java)

                if (lat != null && lng != null) {
                    currentUserLocation = LatLng(lat, lng)
                    Log.d(TAG, "Updated current user location from Firebase: $lat, $lng")

                    // After updating the location, start the monitoring properly
                    initializeMonitoring()
                } else {
                    Log.d(TAG, "Failed to get user location from Firebase, using initial location")
                    initializeMonitoring()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Failed to load current user location", error.toException())
                // Continue with initial location if Firebase fetch fails
                initializeMonitoring()
            }
        })
    }

    private fun initializeMonitoring() {
        // Log current notification preferences
        val notifyPassengers = sharedPrefs.getBoolean("notify_passengers", true)
        val notifyDrivers = sharedPrefs.getBoolean("notify_drivers", true)
        val notificationRadiusKm = sharedPrefs.getFloat("notification_radius_km", DEFAULT_NOTIFICATION_RADIUS_KM)

        Log.d(TAG, "Current notification preferences: " +
                "Notify Passengers: $notifyPassengers, " +
                "Notify Drivers: $notifyDrivers, " +
                "Radius: $notificationRadiusKm km")

        val notificationRadiusMeters = (notificationRadiusKm * 1000).toInt()

        // Always start monitoring for both types
        monitorPassengers(true, notificationRadiusMeters)
        monitorDrivers(true, notificationRadiusMeters)

        isInitialized = true
        Log.d(TAG, "Monitoring started with radius: $notificationRadiusKm km")
    }

    fun updateUserLocation(newLocation: LatLng) {
        currentUserLocation = newLocation
        Log.d(TAG, "Updated user location to: ${newLocation.latitude}, ${newLocation.longitude}")
    }

    private fun monitorPassengers(checkProximity: Boolean, proximityRadius: Int) {
        // Remove any existing listener to avoid duplicates
        passengerListener?.let {
            passengersRef.removeEventListener(it)
            Log.d(TAG, "Removed existing passenger listener")
        }

        passengerListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                scope.launch {
                    val passengerIds = mutableSetOf<String>()
                    val notifyPassengers = sharedPrefs.getBoolean("notify_passengers", true)

                    Log.d(TAG, "Passenger data updated. Notify preference: $notifyPassengers")
                    Log.d(TAG, "Number of passengers in database: ${snapshot.childrenCount}")

                    if (!notifyPassengers) {
                        Log.d(TAG, "Passenger notifications disabled, skipping checks")
                        return@launch
                    }

                    // Loop through each passenger (user ID level)
                    snapshot.children.forEach { passengerSnapshot ->
                        val passengerId = passengerSnapshot.key ?: return@forEach
                        passengerIds.add(passengerId)

                        Log.d(TAG, "Processing passenger: $passengerId (Current user: $userId)")
                        Log.d(TAG, "Current user ID: $userId, Passenger ID: $passengerId, Match: ${userId == passengerId}")

                        // Skip the current user - we don't need to notify about ourselves
                        if (passengerId == userId) {
                            Log.d(TAG, "Skipping current user (passenger ID: $passengerId)")
                            return@forEach
                        }

                        // Get location data directly from the user ID level
                        val lat = passengerSnapshot.child("latitude").getValue(Double::class.java)
                        val lng = passengerSnapshot.child("longitude").getValue(Double::class.java)

                        if (lat != null && lng != null && currentUserLocation != null) {
                            val passengerLocation = LatLng(lat, lng)

                            // Added detailed location logging
                            Log.d(TAG, "Current user location: ${currentUserLocation?.latitude}, ${currentUserLocation?.longitude}")
                            Log.d(TAG, "Passenger location: $lat, $lng")

                            val distance = calculateDistance(currentUserLocation!!, passengerLocation)

                            Log.d(TAG, "Passenger $passengerId at distance $distance meters (radius: $proximityRadius meters)")

                            // Check if passenger is within proximity
                            if (distance <= proximityRadius) {
                                // Only notify if we haven't already notified for this passenger
                                if (knownPassengers[passengerId] != true) {
                                    Log.d(TAG, "Showing notification for passenger $passengerId at distance $distance")

                                    // Check if we should show notifications based on current screen state
                                    if (AppNotificationManager.shouldShowNotifications()) {
                                        if (showPassengerNotification(distance)) {
                                            knownPassengers[passengerId] = true // Mark as notified only if notification was shown
                                            Log.d(TAG, "Successfully notified about passenger $passengerId")
                                        } else {
                                            Log.w(TAG, "Failed to notify about passenger $passengerId")
                                        }
                                    } else {
                                        Log.d(TAG, "Skipping notification - user is not in map screen and background notifications are disabled")
                                    }
                                } else {
                                    Log.d(TAG, "Already notified about passenger $passengerId")
                                }
                            } else {
                                // Reset notification status if user moves out of range
                                if (knownPassengers[passengerId] == true) {
                                    Log.d(TAG, "Passenger $passengerId moved out of range, resetting notification status")
                                    knownPassengers[passengerId] = false
                                }
                            }
                        } else {
                            Log.d(TAG, "Missing location data for passenger $passengerId (lat=$lat, lng=$lng) or current user location: $currentUserLocation")
                        }
                    }

                    // Clean up removed passengers
                    val toRemove = knownPassengers.keys.filter { !passengerIds.contains(it) }
                    if (toRemove.isNotEmpty()) {
                        Log.d(TAG, "Removing ${toRemove.size} passengers that no longer exist in the database")
                        toRemove.forEach { knownPassengers.remove(it) }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Passenger monitoring failed", error.toException())
            }
        }

        passengersRef.addValueEventListener(passengerListener!!)
        Log.d(TAG, "Started monitoring passengers with radius: $proximityRadius meters")
    }

    private fun monitorDrivers(checkProximity: Boolean, proximityRadius: Int) {
        // Remove any existing listener to avoid duplicates
        driverListener?.let {
            driversRef.removeEventListener(it)
            Log.d(TAG, "Removed existing driver listener")
        }

        driverListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                scope.launch {
                    val driverIds = mutableSetOf<String>()
                    val notifyDrivers = sharedPrefs.getBoolean("notify_drivers", true)

                    Log.d(TAG, "Driver data updated. Notify preference: $notifyDrivers")
                    Log.d(TAG, "Number of drivers in database: ${snapshot.childrenCount}")

                    if (!notifyDrivers) {
                        Log.d(TAG, "Driver notifications disabled, skipping checks")
                        return@launch
                    }

                    // Loop through each driver (user ID level)
                    snapshot.children.forEach { driverSnapshot ->
                        val driverId = driverSnapshot.key ?: return@forEach
                        driverIds.add(driverId)

                        Log.d(TAG, "Processing driver: $driverId (Current user: $userId)")
                        Log.d(TAG, "Current user ID: $userId, Driver ID: $driverId, Match: ${userId == driverId}")

                        // Skip the current user - we don't need to notify about ourselves
                        if (driverId == userId) {
                            Log.d(TAG, "Skipping current user (driver ID: $driverId)")
                            return@forEach
                        }

                        // Get location data directly from the user ID level
                        val lat = driverSnapshot.child("latitude").getValue(Double::class.java)
                        val lng = driverSnapshot.child("longitude").getValue(Double::class.java)

                        if (lat != null && lng != null && currentUserLocation != null) {
                            val driverLocation = LatLng(lat, lng)

                            // Added detailed location logging
                            Log.d(TAG, "Current user location: ${currentUserLocation?.latitude}, ${currentUserLocation?.longitude}")
                            Log.d(TAG, "Driver location: $lat, $lng")

                            val distance = calculateDistance(currentUserLocation!!, driverLocation)

                            Log.d(TAG, "Driver $driverId at distance $distance meters (radius: $proximityRadius meters)")

                            // Check if driver is within proximity
                            if (distance <= proximityRadius) {
                                // Only notify if we haven't already notified for this driver
                                if (knownDrivers[driverId] != true) {
                                    Log.d(TAG, "Showing notification for driver $driverId at distance $distance")

                                    // Check if we should show notifications based on current screen state
                                    if (AppNotificationManager.shouldShowNotifications()) {
                                        if (showDriverNotification(distance)) {
                                            knownDrivers[driverId] = true // Mark as notified only if notification was shown
                                            Log.d(TAG, "Successfully notified about driver $driverId")
                                        } else {
                                            Log.w(TAG, "Failed to notify about driver $driverId")
                                        }
                                    } else {
                                        Log.d(TAG, "Skipping notification - user is not in map screen and background notifications are disabled")
                                    }
                                } else {
                                    Log.d(TAG, "Already notified about driver $driverId")
                                }
                            } else {
                                // Reset notification status if user moves out of range
                                if (knownDrivers[driverId] == true) {
                                    Log.d(TAG, "Driver $driverId moved out of range, resetting notification status")
                                    knownDrivers[driverId] = false
                                }
                            }
                        } else {
                            Log.d(TAG, "Missing location data for driver $driverId (lat=$lat, lng=$lng) or current user location: $currentUserLocation")
                        }
                    }

                    // Clean up removed drivers
                    val toRemove = knownDrivers.keys.filter { !driverIds.contains(it) }
                    if (toRemove.isNotEmpty()) {
                        Log.d(TAG, "Removing ${toRemove.size} drivers that no longer exist in the database")
                        toRemove.forEach { knownDrivers.remove(it) }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Driver monitoring failed", error.toException())
            }
        }

        driversRef.addValueEventListener(driverListener!!)
        Log.d(TAG, "Started monitoring drivers with radius: $proximityRadius meters")
    }

    private fun showPassengerNotification(distanceMeters: Float): Boolean {
        // Check for permission first
        if (!hasNotificationPermission()) {
            Log.w(TAG, "Notification permission not granted, skipping passenger notification")
            return false
        }

        val distanceKm = distanceMeters / 1000
        val formattedDistance = String.format("%.1f", distanceKm)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("notification_type", "passenger")
        }

        val pendingIntent = android.app.PendingIntent.getActivity(
            context, 0, intent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT
            }
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("New Passenger Nearby")
            .setContentText("A passenger ($formattedDistance km away) is looking for a ride")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVibrate(longArrayOf(0, 500, 250, 500))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        return try {
            with(NotificationManagerCompat.from(context)) {
                notify(PASSENGER_NOTIFICATION_ID, notification)
                Log.d(TAG, "Passenger notification sent successfully")
            }
            true
        } catch (e: SecurityException) {
            Log.e(TAG, "Failed to send passenger notification due to missing permission", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send passenger notification", e)
            false
        }
    }

    private fun showDriverNotification(distanceMeters: Float): Boolean {
        // Check for permission first
        if (!hasNotificationPermission()) {
            Log.w(TAG, "Notification permission not granted, skipping driver notification")
            return false
        }

        val distanceKm = distanceMeters / 1000
        val formattedDistance = String.format("%.1f", distanceKm)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("notification_type", "driver")
        }

        val pendingIntent = android.app.PendingIntent.getActivity(
            context, 0, intent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT
            }
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("New Taxi Available")
            .setContentText("A taxi is available ($formattedDistance km away)")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVibrate(longArrayOf(0, 500, 250, 500))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        return try {
            with(NotificationManagerCompat.from(context)) {
                notify(DRIVER_NOTIFICATION_ID, notification)
                Log.d(TAG, "Taxi notification sent successfully")
            }
            true
        } catch (e: SecurityException) {
            Log.e(TAG, "Failed to send taxi notification due to missing permission", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send taxi notification", e)
            false
        }
    }

    private fun createNotificationChannel() {
        // Create the notification channel only on API 26+ (Android 8.0 and higher)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Taxi App Notifications"
            val descriptionText = "Notifications for new passengers and drivers"
            val importance = android.app.NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500)
                setShowBadge(true)
            }

            try {
                // Register the channel with the system
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                notificationManager.createNotificationChannel(channel)
                Log.d(TAG, "Notification channel created with importance: $importance")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to create notification channel", e)
            }
        }
    }

    private fun calculateDistance(point1: LatLng, point2: LatLng): Float {
        // Using the Haversine formula to calculate the distance between two coordinates
        val r = 6371000 // Earth radius in meters

        val lat1Rad = Math.toRadians(point1.latitude)
        val lat2Rad = Math.toRadians(point2.latitude)
        val latDelta = Math.toRadians(point2.latitude - point1.latitude)
        val lngDelta = Math.toRadians(point2.longitude - point1.longitude)

        val a = sin(latDelta / 2) * sin(latDelta / 2) +
                cos(lat1Rad) * cos(lat2Rad) *
                sin(lngDelta / 2) * sin(lngDelta / 2)

        val c = 2 * atan2(sqrt(a), sqrt(1 - a))

        return (r * c).toFloat() // Distance in meters
    }

    /**
     * Updates notification preferences and background notification setting
     */
    fun updateNotificationPreferences() {
        if (!isInitialized) {
            Log.w(TAG, "Cannot update preferences: service not initialized")
            return
        }

        // Get user's preferred radius in km, default to 50km
        val notificationRadiusKm = sharedPrefs.getFloat("notification_radius_km", DEFAULT_NOTIFICATION_RADIUS_KM)
        // Convert to meters for internal calculations
        val notificationRadiusMeters = (notificationRadiusKm * 1000).toInt()

        // Update background notification preference
        val allowBackgroundNotifications = sharedPrefs.getBoolean("allow_background_notifications", false)
        AppNotificationManager.setAllowBackgroundNotifications(allowBackgroundNotifications)

        // Only restart if we have a user ID and location
        userId?.let { id ->
            currentUserLocation?.let { location ->
                Log.d(TAG, "Updating notification preferences with radius: $notificationRadiusKm km")
                Log.d(TAG, "Background notifications: $allowBackgroundNotifications")

                // For better logging, get the current preferences
                val notifyPassengers = sharedPrefs.getBoolean("notify_passengers", true)
                val notifyDrivers = sharedPrefs.getBoolean("notify_drivers", true)

                Log.d(TAG, "Updated notification preferences: " +
                        "Passengers=$notifyPassengers, " +
                        "Drivers=$notifyDrivers, " +
                        "Radius=${notificationRadiusKm}km, " +
                        "Background=${allowBackgroundNotifications}")

                // Reset tracking maps to force re-notification with new radius
                knownPassengers.clear()
                knownDrivers.clear()

                // Restart the monitoring with new radius
                monitorPassengers(true, notificationRadiusMeters)
                monitorDrivers(true, notificationRadiusMeters)
            } ?: Log.w(TAG, "Cannot update notification preferences: user location is null")
        } ?: Log.w(TAG, "Cannot update notification preferences: user ID is null")
    }

    fun stopMonitoring() {
        // Remove the Firebase listeners
        passengerListener?.let {
            passengersRef.removeEventListener(it)
            passengerListener = null
            Log.d(TAG, "Stopped passenger monitoring")
        }

        driverListener?.let {
            driversRef.removeEventListener(it)
            driverListener = null
            Log.d(TAG, "Stopped driver monitoring")
        }

        // Cancel any pending coroutines
        notificationJob?.cancel()

        // Clear the tracking maps
        knownPassengers.clear()
        knownDrivers.clear()

        isInitialized = false
        Log.d(TAG, "Stopped all monitoring")
    }

    // Clean up resources when service is no longer needed
    fun cleanup() {
        stopMonitoring()
        scope.cancel()
        Log.d(TAG, "Service cleaned up")
    }
}