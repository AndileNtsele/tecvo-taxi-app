package com.example.taxi

import android.app.Activity
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import androidx.window.layout.WindowMetricsCalculator
import com.example.taxi.deleteUser
import com.google.firebase.auth.*
import com.google.firebase.FirebaseException
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken
import com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import java.util.concurrent.TimeUnit
import com.example.taxi.ui.theme.*
import com.google.firebase.auth.FirebaseAuth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    // 1) Measure screen width and select appropriate dimension object
    val context = LocalContext.current
    val activity = context as? Activity
    val windowMetrics = remember {
        WindowMetricsCalculator.getOrCreate().computeCurrentWindowMetrics(activity!!)
    }
    val screenWidthDp = windowMetrics.bounds.width() / context.resources.displayMetrics.density

    val dimens = when {
        screenWidthDp < 400f -> SettingsScreenCompactSmallDimens
        screenWidthDp in 400f..500f -> SettingsScreenCompactMediumDimens
        screenWidthDp in 500f..600f -> SettingsScreenCompactDimens
        screenWidthDp in 600f..840f -> SettingsScreenMediumDimens
        else -> SettingsScreenExpandedDimens
    }

    // 2) Destructure dimension fields for use in the layout
    val topPadding = dimens.topPadding
    val sidePadding = dimens.sidePadding
    val buttonHeight = dimens.buttonHeight
    val iconSize = dimens.iconSize
    val cornerRadius = dimens.cornerRadius
    val titleTextSize = dimens.titleTextSize
    val spacerWidth = dimens.spacerWidth

    // -----------------------------------------------------------------
    // 3) State Variables
    // -----------------------------------------------------------------
    // Account deletion process state
    var deleteAccountStep by remember { mutableStateOf(0) } // 0 = not started, 1 = phone, 2 = OTP
    var showDeleteAccountDialog by remember { mutableStateOf(false) }

    // Phone verification states
    var phoneNumber by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf("") }
    // Fixed: Explicitly declare the resendToken type as ForceResendingToken?
    var resendToken: ForceResendingToken? by remember { mutableStateOf(null) }
    var isVerifyingPhone by remember { mutableStateOf(false) }
    var isVerifyingOtp by remember { mutableStateOf(false) }
    var phoneError by remember { mutableStateOf("") }
    var otpError by remember { mutableStateOf("") }

    // Account deletion state
    var isProcessingDeletion by remember { mutableStateOf(false) }

    // Notification dialog state
    var showNotificationDialog by remember { mutableStateOf(false) }

    val auth = FirebaseAuth.getInstance()
    val user = auth.currentUser

    // Get saved notification preferences
    val sharedPrefs = context.getSharedPreferences("taxi_app_prefs", Context.MODE_PRIVATE)

    // Load notification preferences
    var passengersNotificationsEnabled by remember {
        mutableStateOf(sharedPrefs.getBoolean("notify_passengers", false))
    }
    var driversNotificationsEnabled by remember {
        mutableStateOf(sharedPrefs.getBoolean("notify_drivers", false))
    }
    var proximityNotificationsEnabled by remember {
        mutableStateOf(sharedPrefs.getBoolean("notify_proximity", false))
    }

    // NEW: Add background notifications preference
    var backgroundNotificationsEnabled by remember {
        mutableStateOf(sharedPrefs.getBoolean("allow_background_notifications", false))
    }

    // Add these right after initializing the notification preferences variables
    // These effects will ensure proximity option follows logical rules
    DisposableEffect(passengersNotificationsEnabled, driversNotificationsEnabled) {
        // If both notification types are disabled, also disable proximity notifications
        if (!passengersNotificationsEnabled && !driversNotificationsEnabled) {
            proximityNotificationsEnabled = false
        }
        onDispose { }
    }

    // Default notification radius is 2km (converted to meters for display)
    // Change notificationRadius to store kilometers instead of meters
    var notificationRadius by remember {
        mutableStateOf(sharedPrefs.getFloat("notification_radius_km", 2.0f).toString())
    }

    // Function to save notification preferences - updated to work with km values directly
    // Function to save notification preferences - add validation
    fun saveNotificationPreferences() {
        // Validation: If proximity is enabled, ensure at least one notification type is selected
        if (proximityNotificationsEnabled && !passengersNotificationsEnabled && !driversNotificationsEnabled) {
            // Can't have proximity without at least one notification type
            proximityNotificationsEnabled = false
            Toast.makeText(
                context,
                "Proximity notifications require at least one notification type to be enabled",
                Toast.LENGTH_LONG
            ).show()
        }

        val radiusInKm = notificationRadius.toFloatOrNull() ?: 2.0f

        with(sharedPrefs.edit()) {
            putBoolean("notify_passengers", passengersNotificationsEnabled)
            putBoolean("notify_drivers", driversNotificationsEnabled)
            putBoolean("notify_proximity", proximityNotificationsEnabled)
            putFloat("notification_radius_km", radiusInKm)
            // NEW: Save background notifications setting
            putBoolean("allow_background_notifications", backgroundNotificationsEnabled)
            apply()
        }

        // If the user is logged in, also save preferences to Firebase
        user?.uid?.let { userId ->
            val database = Firebase.database("https://taxiapp-8aecb-default-rtdb.firebaseio.com/")
            val userPrefsRef = database.getReference("user_preferences/$userId")

            val userPrefs = mapOf(
                "notify_passengers" to passengersNotificationsEnabled,
                "notify_drivers" to driversNotificationsEnabled,
                "notify_proximity" to proximityNotificationsEnabled,
                "notification_radius_km" to radiusInKm,
                // NEW: Include background notifications in Firebase
                "allow_background_notifications" to backgroundNotificationsEnabled
            )

            userPrefsRef.setValue(userPrefs)
        }
        // Update the active notification service with new preferences
        (context.applicationContext as TaxiApplication).updateNotificationServicePreferences()
    }

    // -----------------------------------------------------------------
    // 5) Scaffold with TopBar
    // -----------------------------------------------------------------
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text("Settings", fontSize = titleTextSize)
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Route.HOME) }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back to Home"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        // Main Column
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .padding(horizontal = sidePadding, vertical = topPadding),
            verticalArrangement = Arrangement.spacedBy(topPadding)
        ) {
            // Notification Settings Button
            SettingsButton(
                text = "Notification Settings",
                icon = Icons.Default.Notifications,
                onClick = { showNotificationDialog = true },
                buttonHeight = buttonHeight,
                iconSize = iconSize,
                spacerWidth = spacerWidth,
                cornerRadius = cornerRadius
            )

            // Delete Account Button
            SettingsButton(
                text = "Delete Account",
                icon = Icons.Default.DeleteForever,
                onClick = { showDeleteAccountDialog = true },
                color = Color.Red,
                buttonHeight = buttonHeight,
                iconSize = iconSize,
                spacerWidth = spacerWidth,
                cornerRadius = cornerRadius
            )
        }

        // Show the improved notification settings dialog
        ImprovedNotificationSettingsDialog(
            showDialog = showNotificationDialog,
            onDismiss = { showNotificationDialog = false },
            sharedPrefs = sharedPrefs
        )

        // -----------------------------------------------------------------
        // 7) Delete Account Flow Dialogs
        // -----------------------------------------------------------------
        if (showDeleteAccountDialog) {
            // First dialog: Warning about account deletion
            AlertDialog(
                onDismissRequest = {
                    showDeleteAccountDialog = false
                    deleteAccountStep = 0
                },
                title = { Text("Delete Account", color = Color.Red) },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            "WARNING: You are about to delete your account",
                            color = Color.Red,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                        )
                        Text("This action cannot be undone")

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFFFFECEC)
                            )
                        ) {
                            Text(
                                "You will need to verify your identity through phone verification before account deletion.",
                                modifier = Modifier.padding(16.dp),
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showDeleteAccountDialog = false
                            deleteAccountStep = 1 // Move to phone verification step
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Red
                        )
                    ) {
                        Text("Proceed to Verification")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showDeleteAccountDialog = false
                        deleteAccountStep = 0
                    }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Step 1: Phone Verification Dialog
        if (deleteAccountStep == 1) {
            AlertDialog(
                onDismissRequest = {
                    deleteAccountStep = 0
                    phoneError = ""
                },
                title = { Text("Step 1: Verify Phone Number") },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("Please enter the phone number to verify your identity")

                        if (phoneError.isNotEmpty()) {
                            Text(
                                text = phoneError,
                                color = Color.Red,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }

                        OutlinedTextField(
                            value = phoneNumber,
                            onValueChange = { phoneNumber = it },
                            label = { Text("Phone Number") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = {
                                Text(
                                    "+",
                                    modifier = Modifier.padding(start = 16.dp),
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            },
                            placeholder = { Text("1234567890 (include country code)") }
                        )

                        Text(
                            "A verification code will be sent to this number",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            // Verify phone number with Firebase
                            if (phoneNumber.isNotEmpty()) {
                                isVerifyingPhone = true
                                phoneError = ""

                                val formattedPhoneNumber = if (phoneNumber.startsWith("+")) {
                                    phoneNumber
                                } else {
                                    "+$phoneNumber"
                                }

                                val callbacks = object : OnVerificationStateChangedCallbacks() {
                                    override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                                        isVerifyingPhone = false
                                        // Auto-verification if possible (rare)
                                        // Delete account directly when auto-verified
                                        deleteUser(user, context, navController)
                                    }

                                    override fun onVerificationFailed(e: FirebaseException) {
                                        isVerifyingPhone = false
                                        phoneError = e.message ?: "Verification failed"
                                    }

                                    override fun onCodeSent(
                                        receivedVerificationId: String,
                                        token: ForceResendingToken
                                    ) {
                                        isVerifyingPhone = false
                                        // Save verification ID and resending token for later use
                                        verificationId = receivedVerificationId
                                        resendToken = token

                                        // Move to OTP verification step
                                        deleteAccountStep = 2
                                    }
                                }

                                val options = PhoneAuthOptions.newBuilder(auth)
                                    .setPhoneNumber(formattedPhoneNumber)
                                    .setTimeout(60L, TimeUnit.SECONDS)
                                    .setActivity(activity!!)
                                    .setCallbacks(callbacks)
                                    .build()

                                PhoneAuthProvider.verifyPhoneNumber(options)
                            } else {
                                phoneError = "Please enter a phone number"
                            }
                        },
                        enabled = !isVerifyingPhone && phoneNumber.isNotEmpty()
                    ) {
                        if (isVerifyingPhone) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        } else {
                            Text("Send Verification Code")
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { deleteAccountStep = 0 }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Step 2: OTP Verification Dialog with Direct Account Deletion
        if (deleteAccountStep == 2) {
            AlertDialog(
                onDismissRequest = {
                    deleteAccountStep = 1 // Go back to phone step
                    otpError = ""
                },
                title = { Text("Step 2: Enter Verification Code") },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("We've sent a verification code to $phoneNumber")

                        if (otpError.isNotEmpty()) {
                            Text(
                                text = otpError,
                                color = Color.Red,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }

                        OutlinedTextField(
                            value = otpCode,
                            onValueChange = { if (it.length <= 6) otpCode = it },
                            label = { Text("6-digit Code") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        TextButton(
                            onClick = {
                                // Resend OTP logic
                                isVerifyingOtp = true
                                val callbacks = object : OnVerificationStateChangedCallbacks() {
                                    override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                                        isVerifyingOtp = false
                                    }

                                    override fun onVerificationFailed(e: FirebaseException) {
                                        isVerifyingOtp = false
                                        otpError = e.message ?: "Verification failed"
                                    }

                                    override fun onCodeSent(
                                        receivedVerificationId: String,
                                        token: ForceResendingToken
                                    ) {
                                        isVerifyingOtp = false
                                        verificationId = receivedVerificationId
                                        resendToken = token
                                        Toast.makeText(context, "OTP code resent", Toast.LENGTH_SHORT).show()
                                    }
                                }

                                val formattedPhoneNumber = if (phoneNumber.startsWith("+")) {
                                    phoneNumber
                                } else {
                                    "+$phoneNumber"
                                }

                                val options = PhoneAuthOptions.newBuilder(auth)
                                    .setPhoneNumber(formattedPhoneNumber)
                                    .setTimeout(60L, TimeUnit.SECONDS)
                                    .setActivity(activity!!)
                                    .setCallbacks(callbacks)
                                    .apply {
                                        if (resendToken != null) {
                                            setForceResendingToken(resendToken!!)
                                        }
                                    }
                                    .build()

                                PhoneAuthProvider.verifyPhoneNumber(options)
                            },
                            modifier = Modifier.align(Alignment.CenterHorizontally),
                            enabled = !isVerifyingOtp
                        ) {
                            Text("Didn't receive a code? Resend")
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            // Verify OTP and delete account
                            if (otpCode.length == 6) {
                                isVerifyingOtp = true
                                otpError = ""
                                isProcessingDeletion = true

                                try {
                                    val credential = PhoneAuthProvider.getCredential(verificationId, otpCode)

                                    // Sign in with the credential to verify OTP
                                    auth.signInWithCredential(credential)
                                        .addOnCompleteListener { task ->
                                            isVerifyingOtp = false
                                            if (task.isSuccessful) {
                                                // OTP verified successfully, proceed to delete account
                                                deleteUser(user, context, navController)
                                            } else {
                                                isProcessingDeletion = false
                                                otpError = task.exception?.message ?: "Invalid verification code"
                                            }
                                        }
                                } catch (e: Exception) {
                                    isVerifyingOtp = false
                                    isProcessingDeletion = false
                                    otpError = e.message ?: "Invalid verification code"
                                }
                            } else {
                                otpError = "Please enter a 6-digit code"
                            }
                        },
                        enabled = !isVerifyingOtp && !isProcessingDeletion && otpCode.length == 6,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Red
                        )
                    ) {
                        if (isVerifyingOtp || isProcessingDeletion) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        } else {
                            Text("Verify and Delete Account")
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { deleteAccountStep = 1 }) {
                        Text("Back")
                    }
                }
            )
        }
    }
}

// Helper function to delete the user account
private fun deleteUser(user: FirebaseUser?, context: android.content.Context, navController: NavController) {
    // Delete the user account
    user?.delete()?.addOnCompleteListener { deleteTask ->
        if (deleteTask.isSuccessful) {
            // Account deleted successfully
            Toast.makeText(context, "Account deleted successfully", Toast.LENGTH_LONG).show()

            // Navigate to login screen
            navController.navigate(Route.LOGIN) {
                popUpTo(Route.HOME) { inclusive = true }
            }
        } else {
            Toast.makeText(
                context,
                "Failed to delete account: ${deleteTask.exception?.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

@Composable
private fun SettingsButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    color: Color = MaterialTheme.colorScheme.primary,
    buttonHeight: Dp,
    iconSize: Dp,
    spacerWidth: Dp,
    cornerRadius: Dp
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(buttonHeight),
        shape = RoundedCornerShape(cornerRadius),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (color == Color.Red) Color.Red else MaterialTheme.colorScheme.primary
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(iconSize)
            )
            Spacer(modifier = Modifier.width(spacerWidth))
            Text(text = text)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SettingsScreenPreview() {
    val navController = rememberNavController()
    SettingsScreen(navController)
}