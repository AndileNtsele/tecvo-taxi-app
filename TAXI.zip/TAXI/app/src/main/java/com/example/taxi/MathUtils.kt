package com.example.taxi

// Extension function to calculate power of a Double number
fun Double.pow(n: Int): Double = Math.pow(this, n.toDouble())