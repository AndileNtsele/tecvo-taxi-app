@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.taxi

import android.app.Activity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import androidx.window.layout.WindowMetricsCalculator
import com.example.taxi.ui.theme.*


@Composable
fun HomeScreen(navController: NavController) {
    // 1) Determine screen width & pick the dimension object
    val context = LocalContext.current
    val windowMetrics = remember {
        WindowMetricsCalculator.getOrCreate().computeCurrentWindowMetrics(context as Activity)
    }
    val screenWidthDp = windowMetrics.bounds.width() / context.resources.displayMetrics.density

    val dimens = when {
        screenWidthDp < 400f -> HomeScreenCompactSmallDimens
        screenWidthDp in 400f..500f -> HomeScreenCompactMediumDimens
        screenWidthDp in 500f..600f -> HomeScreenCompactDimens
        screenWidthDp in 600f..840f -> HomeScreenMediumDimens
        else -> HomeScreenExpandedDimens
    }

    // 2) Expose dimension fields for clarity and maintainability
    val buttonHeight = dimens.buttonHeight
    val buttonWidth = dimens.buttonWidth
    val bigSpacerHeight = dimens.bigSpacerHeight
    val mediumSpacerHeight = dimens.mediumSpacerHeight
    val appLogoSize = dimens.appLogoSize
    val textSize = dimens.textSize
    val buttonCornerRadius = dimens.buttonCornerRadius
    val settingsIconSize = dimens.settingsIconSize
    val appLogoBottomPadding = dimens.appLogoBottomPadding
    val smallSpacerHeight = dimens.smallSpacerHeight
    val settingsIconCornerRadius = dimens.settingsIconCornerRadius
    val screenPadding = dimens.screenPadding
    val settingsBottomPadding = dimens.settingsBottomPadding
    val settingsEndPadding = dimens.settingsEndPadding
    val dividerPadding = dimens.dividerPadding

    // Box container for the whole screen
    Box(modifier = Modifier.fillMaxSize()) {
        // Background image with reduced opacity
        Image(
            painter = painterResource(id = R.drawable.background_image), // Add your background image
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.8f // Adjust opacity here (0.0f to 1.0f, where 0 is invisible)
        )

        // Gradient overlay on top of the image for better contrast
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF0A1F44).copy(alpha = 0.85f), // Dark blue at the top
                            Color(0xFF16294B).copy(alpha = 0.85f)  // Slightly lighter blue at the bottom
                        )
                    )
                )
        )

        // Main content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(screenPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(bigSpacerHeight))

            // Logo
            Image(
                painter = painterResource(id = R.drawable.applogo),
                contentDescription = "App Logo",
                modifier = Modifier
                    .size(appLogoSize)
                    .padding(bottom = appLogoBottomPadding),
                contentScale = ContentScale.Fit
            )

            Spacer(modifier = Modifier.height(bigSpacerHeight))

            // Title
            Text(
                text = "Who are you?",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                fontSize = textSize,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(mediumSpacerHeight))

            // Passenger Button
            Button(
                onClick = { navController.navigate("passenger") },
                modifier = Modifier
                    .width(buttonWidth)
                    .height(buttonHeight),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(buttonCornerRadius)
            ) {
                Text(
                    text = "Passenger",
                    fontSize = textSize,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(smallSpacerHeight))

            // Divider
            Row(
                modifier = Modifier.width(buttonWidth),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Divider(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = dividerPadding),
                    color = Color.White.copy(alpha = 0.3f)
                )
                Text(
                    text = "or",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = textSize
                )
                Divider(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = dividerPadding),
                    color = Color.White.copy(alpha = 0.3f)
                )
            }

            Spacer(modifier = Modifier.height(smallSpacerHeight))

            // Driver Button
            Button(
                onClick = { navController.navigate("driver") },
                modifier = Modifier
                    .width(buttonWidth)
                    .height(buttonHeight),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(buttonCornerRadius)
            ) {
                Text(
                    text = "Driver",
                    fontSize = textSize,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Settings Icon
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = settingsBottomPadding, end = settingsEndPadding),
            contentAlignment = Alignment.BottomEnd
        ) {
            IconButton(
                onClick = { navController.navigate("settings") },
                modifier = Modifier
                    .size(settingsIconSize)
                    .background(
                        color = Color.White.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(settingsIconCornerRadius)
                    )
                    .padding(4.dp)
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.settings),
                    contentDescription = "Settings",
                    tint = Color.White,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
@Preview(showBackground = true)
fun HomeScreenPreview() {
    HomeScreen(navController = rememberNavController())
}