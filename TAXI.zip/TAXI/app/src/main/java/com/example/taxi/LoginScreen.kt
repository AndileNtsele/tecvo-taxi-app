@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalComposeUiApi::class)

package com.example.taxi

import android.app.Activity
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.*
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import androidx.window.layout.WindowMetricsCalculator
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import com.google.accompanist.insets.statusBarsPadding
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.math.sqrt
import com.example.taxi.models.Country
import com.example.taxi.ui.theme.*
import com.example.taxi.utils.CountryUtils
import com.google.firebase.auth.PhoneAuthCredential

// ---------------------- Sealed Classes ----------------------
sealed class LoginResult {
    object Success : LoginResult()
    data class Error(val message: String) : LoginResult()
    object Loading : LoginResult()
    object Idle : LoginResult()
}

// ---------------------- ViewModel ----------------------
class LoginViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()

    private val _loginState = MutableStateFlow<LoginResult>(LoginResult.Idle)
    val loginState: StateFlow<LoginResult> = _loginState

    fun isUserLoggedIn(): Boolean {
        return auth.currentUser != null
    }
}

// ---------------------- LoginScreen ----------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(navController: NavController, viewModel: LoginViewModel = viewModel()) {
    // 1) Determine screen width and pick the appropriate dimension object
    val context = LocalContext.current
    val windowMetrics = remember {
        WindowMetricsCalculator.getOrCreate().computeCurrentWindowMetrics(context as Activity)
    }
    val screenWidthDp = windowMetrics.bounds.width() / context.resources.displayMetrics.density

    val dimens = when {
        screenWidthDp < 400f -> LoginScreenCompactSmallDimens
        screenWidthDp in 400f..500f -> LoginScreenCompactMediumDimens
        screenWidthDp in 500f..600f -> LoginScreenCompactDimens
        screenWidthDp in 600f..840f -> LoginScreenMediumDimens
        else -> LoginScreenExpandedDimens
    }

    // 2) Expose the dimension fields from the chosen variant
    val small3 = dimens.small3
    val medium1 = dimens.medium1
    val medium2 = dimens.medium2
    val logoSize = dimens.logoSize
    val textFieldHeight = dimens.textFieldHeight

    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current

    val scrollState = rememberScrollState()
    val systemUiController = rememberSystemUiController()
    val keyboardController = LocalSoftwareKeyboardController.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Login states
    var phoneNumber by rememberSaveable { mutableStateOf("") }
    var otp by rememberSaveable { mutableStateOf("") }
    var isOtpSent by rememberSaveable { mutableStateOf(false) }
    var verificationId by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedCountry by rememberSaveable(stateSaver = Country.Saver) {
        mutableStateOf(CountryUtils.DEFAULT_COUNTRY)
    }
    var isLoginClicked by rememberSaveable { mutableStateOf(false) }
    var showLoginForm by remember { mutableStateOf(false) }
    var loginError by remember { mutableStateOf<String?>(null) }
    var isImeVisible by remember { mutableStateOf(false) }

    // Terms and conditions state
    var termsAccepted by rememberSaveable { mutableStateOf(false) }

    val loginState by viewModel.loginState.collectAsState()

    // Handle keyboard visibility
    val view = LocalView.current
    LaunchedEffect(view) {
        ViewCompat.setOnApplyWindowInsetsListener(view) { _, insets ->
            isImeVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            insets
        }
    }

    // Adjust system bar color
    LaunchedEffect(isImeVisible) {
        systemUiController.setSystemBarsColor(Color(0xFF0A1F44))
    }

    // ------------------ MAIN CONTAINER ------------------
    Box(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        // Gradient background
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF0A1F44), // Dark blue at the top
                            Color(0xFF16294B)  // Slightly lighter blue at the bottom
                        )
                    )
                )
        )

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Animated visibility for the top logo (if not typing and not logged in yet)
            AnimatedVisibility(
                visible = !isImeVisible && !isLoginClicked,
                enter = fadeIn(animationSpec = tween(durationMillis = 500)) +
                        expandVertically(animationSpec = tween(durationMillis = 500)),
                exit = fadeOut() + shrinkVertically()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = medium1),
                    contentAlignment = Alignment.Center
                ) {
                    // Modernized logo presentation with shadow effect
                    Image(
                        painter = painterResource(id = R.drawable.applogo),
                        contentDescription = "App Logo",
                        modifier = Modifier
                            .size(logoSize)
                            .shadow(
                                elevation = 12.dp,
                                shape = CircleShape,
                                spotColor = Color(0xFF001A66).copy(alpha = 0.5f)
                            ),
                        contentScale = ContentScale.Fit
                    )
                }
            }

            // ------------------ LOGIN FORM ------------------
            if (showLoginForm && !isLoginClicked) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White,
                    shape = RoundedCornerShape(
                        topStart = 28.dp,
                        topEnd = 28.dp
                    ),
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(
                                top = 32.dp,
                                bottom = 24.dp,
                                start = 24.dp,
                                end = 24.dp
                            )
                            .verticalScroll(scrollState),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        Text(
                            text = "Register",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontSize = dimens.loginTextSize,
                                fontWeight = FontWeight.Bold
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // ------------------ PHONE & OTP ------------------
                        if (!isOtpSent) {
                            ModernPhoneNumberField(
                                selectedCountry = selectedCountry,
                                onCountrySelected = { chosenCountry ->
                                    selectedCountry = chosenCountry
                                },
                                phoneNumber = phoneNumber,
                                onPhoneNumberChange = { newValue ->
                                    phoneNumber = newValue
                                    loginError = null
                                }
                            )
                        } else {
                            ModernOtpField(
                                otp = otp,
                                onOtpChange = {
                                    if (it.length <= 6) otp = it
                                    loginError = null
                                },
                                onSubmit = {
                                    if (otp.length == 6) {
                                        PhoneAuthHelper.verifyPhoneNumberWithCode(
                                            verificationId = verificationId ?: "",
                                            code = otp,
                                            onSuccess = { isLoginClicked = true },
                                            onError = { error -> loginError = error }
                                        )
                                    }
                                }
                            )
                        }

                        // ------------------ TERMS AND CONDITIONS CHECKBOX ------------------
                        if (!isOtpSent) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = termsAccepted,
                                    onCheckedChange = { termsAccepted = it },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = MaterialTheme.colorScheme.primary
                                    )
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "I agree to the Terms of Service and Privacy Policy",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.clickable {
                                        navController.navigate(Route.TERMS_AND_CONDITIONS)
                                    }
                                )
                            }
                        }

                        // ------------------ ERROR MESSAGE ------------------
                        if (loginError != null) {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0xFFFFF3F3)
                                ),
                                border = BorderStroke(1.dp, Color(0xFFFFCCCC)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Error,
                                        contentDescription = "Error",
                                        tint = Color.Red,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = loginError ?: "",
                                        color = Color.Red,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }

                        // ------------------ LOGIN BUTTON ------------------
                        ElevatedButton(
                            onClick = {
                                handlePhoneLogin(
                                    isOtpSent = isOtpSent,
                                    phoneNumber = phoneNumber,
                                    selectedCountry = selectedCountry,
                                    otp = otp,
                                    verificationId = verificationId,
                                    context = context,
                                    onVerificationIdReceived = { id ->
                                        verificationId = id
                                        isOtpSent = true
                                        loginError = null
                                    },
                                    onLoginSuccess = { isLoginClicked = true },
                                    onError = { error: String -> loginError = error }
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp),
                            enabled = ((!isOtpSent && CountryUtils.isValidPhoneNumber(phoneNumber, selectedCountry) && termsAccepted) ||
                                    (isOtpSent && otp.length == 6)),
                            shape = RoundedCornerShape(16.dp),
                            elevation = ButtonDefaults.elevatedButtonElevation(
                                defaultElevation = 6.dp,
                                pressedElevation = 8.dp
                            )
                        ) {
                            if (loginState is LoginResult.Loading) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 3.dp
                                )
                            } else {
                                Text(
                                    text = if (isOtpSent) "Login" else "Verify Phone Number",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Initial animations and focus
    LaunchedEffect(Unit) {
        delay(1500)
        showLoginForm = true
    }

    // Navigate on successful login
    LaunchedEffect(isLoginClicked) {
        if (isLoginClicked) {
            delay(500)
            navController.navigate("home") {
                popUpTo("login") { inclusive = true }
            }
        }
    }
}

// ------------------ Modernized Phone Number Field ------------------
@Composable
fun ModernPhoneNumberField(
    selectedCountry: Country,
    onCountrySelected: (Country) -> Unit,
    phoneNumber: String,
    onPhoneNumberChange: (String) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    val isValid = CountryUtils.isValidLocalPhoneNumber(phoneNumber, selectedCountry)
    val phoneError = if (!isValid && phoneNumber.isNotEmpty()) {
        "Invalid number for ${selectedCountry.name}"
    } else null

    // Get local number example for the selected country
    val localNumberExample = remember(selectedCountry) {
        CountryUtils.getLocalNumberExample(selectedCountry.code)
    }

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "Phone Number",
            style = MaterialTheme.typography.labelLarge,
            color = Color.Gray,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFF5F5F5)
            ),
            border = BorderStroke(
                width = 1.dp,
                color = if (phoneError != null) Color.Red else Color(0xFFE0E0E0)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Country selector
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { showDialog = true }
                        .background(Color(0xFFEBEBEB))
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = selectedCountry.flagEmoji,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = selectedCountry.dialCode,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Icon(
                            imageVector = Icons.Rounded.ArrowDropDown,
                            contentDescription = "Select country",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Phone number field with local number example
                BasicTextField(
                    value = phoneNumber,
                    onValueChange = onPhoneNumberChange,
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 12.dp),
                    textStyle = TextStyle(
                        fontSize = 16.sp,
                        color = Color.Black
                    ),
                    keyboardOptions = KeyboardOptions.Default.copy(
                        keyboardType = KeyboardType.Phone
                    ),
                    decorationBox = { innerTextField ->
                        Box(modifier = Modifier.fillMaxWidth()) {
                            if (phoneNumber.isEmpty()) {
                                Text(
                                    text = "Example: $localNumberExample", // Local format example
                                    color = Color.Gray,
                                    fontSize = 16.sp
                                )
                            }
                            innerTextField()
                        }
                    }
                )

                Icon(
                    imageVector = Icons.Rounded.Phone,
                    contentDescription = "Phone",
                    tint = Color.Gray,
                    modifier = Modifier.padding(end = 12.dp)
                )
            }
        }

        phoneError?.let { errorMsg ->
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Error,
                    contentDescription = "Error",
                    tint = Color.Red,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = errorMsg,
                    color = Color.Red,
                    fontSize = 14.sp
                )
            }
        }

        // Helper text to explain local number format
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Enter your local number without country code",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            modifier = Modifier.padding(start = 4.dp)
        )
    }

    if (showDialog) {
        ModernCountryPickerDialog(
            open = true,
            onDismiss = { showDialog = false },
            onSelectCountry = { country ->
                onCountrySelected(country)
                showDialog = false
            }
        )
    }
}

// ------------------ Modernized OTP Field ------------------
@Composable
fun ModernOtpField(
    otp: String,
    onOtpChange: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Enter OTP",
            style = MaterialTheme.typography.labelLarge,
            color = Color.Gray,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFF5F5F5)
            ),
            border = BorderStroke(1.dp, Color(0xFFE0E0E0))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = otp,
                    onValueChange = onOtpChange,
                    modifier = Modifier.weight(1f),
                    textStyle = TextStyle(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        letterSpacing = 4.sp,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions.Default.copy(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { onSubmit() }
                    ),
                    decorationBox = { innerTextField ->
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            if (otp.isEmpty()) {
                                Text(
                                    text = "Enter 6-digit code",
                                    color = Color.Gray,
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                            innerTextField()
                        }
                    }
                )

                Icon(
                    imageVector = Icons.Rounded.Lock,
                    contentDescription = "OTP",
                    tint = Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "We've sent a verification code to your phone",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

// ------------------ Modernized Country Picker Dialog ------------------
@Composable
fun ModernCountryPickerDialog(
    open: Boolean,
    onDismiss: () -> Unit,
    onSelectCountry: (Country) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredCountries = remember(searchQuery) {
        CountryUtils.allCountries.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.dialCode.contains(searchQuery, ignoreCase = true)
        }
    }

    if (open) {
        AlertDialog(
            onDismissRequest = onDismiss,
            confirmButton = {},
            dismissButton = {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Text("Cancel")
                }
            },
            shape = RoundedCornerShape(24.dp),
            containerColor = Color.White,
            title = {
                Text(
                    "Select Your Country",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold
                    )
                )
            },
            text = {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search by name or code") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = Color.LightGray,
                            containerColor = Color(0xFFF5F5F5)
                        ),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = Color.Gray
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 350.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filteredCountries) { country ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectCountry(country) },
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0xFFF5F5F5)
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp, horizontal = 16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        country.flagEmoji,
                                        fontSize = 24.sp
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(
                                            country.name,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.Medium
                                            )
                                        )
                                        Text(
                                            country.dialCode,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        )
    }
}

// ------------------ Helper Function for Phone Login ------------------
private fun handlePhoneLogin(
    isOtpSent: Boolean,
    phoneNumber: String,
    selectedCountry: Country,
    otp: String,
    verificationId: String?,
    context: Context,
    onVerificationIdReceived: (String) -> Unit,
    onLoginSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    if (!isOtpSent && CountryUtils.isValidLocalPhoneNumber(phoneNumber, selectedCountry)) {
        // Format the phone number for Firebase authentication
        val formattedNumber = formatPhoneNumberForAuth(phoneNumber, selectedCountry)

        PhoneAuthHelper.signUpWithPhone(
            phoneNumber = formattedNumber,
            activity = context as Activity,
            onCodeSent = onVerificationIdReceived,
            onVerificationCompleted = { credential ->
                PhoneAuthHelper.verifyPhoneNumberWithCode(
                    verificationId = verificationId ?: "",
                    code = otp,
                    onSuccess = onLoginSuccess,
                    onError = onError
                )
            },
            onError = onError
        )
    } else if (isOtpSent && otp.length == 6) {
        PhoneAuthHelper.verifyPhoneNumberWithCode(
            verificationId = verificationId ?: "",
            code = otp,
            onSuccess = onLoginSuccess,
            onError = onError
        )
    }
}

// Helper function to format local phone numbers for authentication
private fun formatPhoneNumberForAuth(localNumber: String, country: Country): String {
    // Remove spaces, hyphens, and parentheses
    val cleanNumber = localNumber.replace(Regex("[\\s-()]"), "")

    // If the number starts with a zero, remove it before adding the country code
    val trimmedNumber = if (cleanNumber.startsWith("0")) {
        cleanNumber.substring(1)
    } else {
        cleanNumber
    }

    // Return the full international format
    return "${country.dialCode}$trimmedNumber"
}

// ---------------------- Preview ----------------------
@Composable
@Preview(showBackground = true)
fun LoginScreenPreview() {
    LoginScreen(navController = rememberNavController())
}