// Package declaration indicates that this file is part of the 'utils' package within the 'com.example.taxi' project.
package com.example.taxi.utils

// Import necessary Android and Kotlin libraries for handling permissions and compatibility.
import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * PermissionHandler is a singleton object responsible for managing storage-related permissions
 * required by the application. It checks if the necessary permissions are granted and requests
 * them if they are not.
 */
object PermissionHandler {

    /**
     * STORAGE_PERMISSIONS holds an array of permission strings that the application needs
     * to access device storage. The specific permissions vary based on the device's Android SDK version.
     *
     * - For Android Tiramisu (API level 33) and above:
     *   - READ_MEDIA_IMAGES: Permission to read image files.
     *   - READ_MEDIA_VIDEO: Permission to read video files.
     *   - READ_MEDIA_AUDIO: Permission to read audio files.
     *
     * - For Android versions below Tiramisu:
     *   - READ_EXTERNAL_STORAGE: Permission to read from external storage.
     *   - WRITE_EXTERNAL_STORAGE: Permission to write to external storage.
     */
    private val STORAGE_PERMISSIONS = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO
        )
    } else {
        arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
    }

    /**
     * checkAndRequestPermissions is a function that verifies whether the required storage permissions
     * are already granted. If any permissions are missing, it requests them from the user.
     *
     * @param activity The current Activity context from which permissions are being requested.
     *
     * Workflow:
     * 1. Filters the STORAGE_PERMISSIONS array to identify which permissions are not yet granted.
     * 2. Converts the list of ungranted permissions to an array.
     * 3. If there are any permissions that are not granted, it requests those permissions.
     *    - Uses ActivityCompat.requestPermissions to prompt the user.
     *    - The request code '123' is an arbitrary integer used to identify this permission request
     *      in the callback (e.g., onRequestPermissionsResult).
     */
    fun checkAndRequestPermissions(activity: Activity) {
        // Identify which permissions from STORAGE_PERMISSIONS are not yet granted.
        val permissionsNeeded = STORAGE_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(activity, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()

        // If there are any permissions that need to be requested, initiate the permission request.
        if (permissionsNeeded.isNotEmpty()) {
            // Request the necessary permissions from the user.
            ActivityCompat.requestPermissions(activity, permissionsNeeded, 123)
        }
    }
}
