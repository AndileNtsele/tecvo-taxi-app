package com.example.taxi

// Import necessary Android and Jetpack Compose libraries
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.taxi.ui.theme.TaxiTheme
import com.example.taxi.utils.PermissionHandler
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import com.google.firebase.FirebaseApp
import java.io.File
import com.google.firebase.auth.FirebaseAuth
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavController
import com.google.android.gms.maps.model.LatLng
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.database.FirebaseDatabase

/**
 * MainActivity serves as the entry point of the Taxi application.
 * It handles initialization tasks such as setting up Firebase, requesting permissions,
 * creating necessary directories, and setting up the navigation between different screens.
 */
class MainActivity : ComponentActivity() {

    // ActivityResultLauncher to handle the result of location permission requests
    private lateinit var locationPermissionRequest: ActivityResultLauncher<String>

    // ActivityResultLauncher to handle the result of notification permission requests
    private lateinit var notificationPermissionRequest: ActivityResultLauncher<String>

    // Service for map notifications
    private lateinit var mapNotificationService: MapNotificationService

    // FusedLocationProviderClient for getting user location
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    companion object {
        private const val NOTIFICATION_PERMISSION_CODE = 100
        private const val TAG = "MainActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Enable edge-to-edge display for a more immersive UI experience
        enableEdgeToEdge()

        // Call the superclass implementation of onCreate
        super.onCreate(savedInstanceState)

        // Initialize Firebase SDK for backend services
        FirebaseApp.initializeApp(this)

        // Initialize FusedLocationProviderClient
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Check and request necessary permissions when the app starts
        PermissionHandler.checkAndRequestPermissions(this)

        // Create any required directories for the app's storage needs
        createAppDirectories()

        // Initialize the MapNotificationService
        mapNotificationService = MapNotificationService(this)

        // Set up the location permission request mechanism
        setupLocationPermission()

        // Set up the notification permission request mechanism
        setupNotificationPermission()

        // Set the content of the activity to the composable function AppNavigation
        setContent {
            AppNavigation()
        }
    }

    /**
     * Creates necessary directories for the application, such as the OBB directory.
     * This is useful for storing large files required by the app.
     */
    private fun createAppDirectories() {
        try {
            // Define the path for the OBB directory specific to this app
            val obbDir = File(getExternalFilesDir(null), "Android/obb/com.example.taxi")
            // Create the directory if it does not already exist
            if (!obbDir.exists()) {
                obbDir.mkdirs()
            }
        } catch (e: Exception) {
            // Log an error message if directory creation fails
            Log.e(TAG, "Failed to create directories", e)
        }
    }

    /**
     * Sets up the mechanism to request location permissions from the user.
     * It registers a callback to handle the user's response to the permission request.
     */
    private fun setupLocationPermission() {
        // Register a callback to handle the result of the location permission request
        locationPermissionRequest = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                // If permission is granted, show a success message
                showToast("Location permission granted!")

                // Check if user is logged in and notification permission is granted
                checkUserAndStartMonitoring()
            } else {
                // If permission is denied, show a failure message
                showToast("Location permission denied!")

                // Show dialog explaining why location permission is important
                showLocationPermissionExplanationDialog()
            }
        }

        // If the location permission is not already granted, request it
        if (!isLocationPermissionGranted()) {
            locationPermissionRequest.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            // Location permission already granted, check notification and user status
            checkUserAndStartMonitoring()
        }
    }

    /**
     * Sets up the mechanism to request notification permissions from the user.
     * This is required for Android 13 (API 33) and higher.
     */
    private fun setupNotificationPermission() {
        // Register a callback to handle the result of the notification permission request
        notificationPermissionRequest = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                // If permission is granted, show a success message
                showToast("Notification permission granted!")

                // Check if user is logged in and location permission is granted
                checkUserAndStartMonitoring()
            } else {
                // If permission is denied, show a failure message
                showToast("Notification permission denied!")

                // Show explanation dialog
                mapNotificationService.showNotificationPermissionExplanationDialog(this)

                // Still check if we can start monitoring without notifications
                checkUserAndStartMonitoring()
            }
        }

        // Request notification permission only for Android 13+ devices
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!isNotificationPermissionGranted()) {
                notificationPermissionRequest.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                // Notification permission already granted, check location and user status
                checkUserAndStartMonitoring()
            }
        } else {
            // For older Android versions, notification permission is not required
            // Check location permission and user status
            checkUserAndStartMonitoring()
        }
    }

    /**
     * Checks if a user is logged in and location permission is granted before starting monitoring.
     */
    private fun checkUserAndStartMonitoring() {
        val currentUser = FirebaseAuth.getInstance().currentUser

        if (currentUser != null && isLocationPermissionGranted()) {
            // Get current location with callback
            getCurrentLocation { location ->
                // Start monitoring with both notification service implementations
                startLocationAndMonitoring(currentUser.uid, location)
            }
        }
    }

    /**
     * Gets the current device location using FusedLocationProviderClient.
     * Falls back to Firebase stored location or default coordinates if needed.
     *
     * @param callback Function to call with the resolved location
     */
    private fun getCurrentLocation(callback: (LatLng) -> Unit) {
        Log.d(TAG, "Getting current location...")

        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    Log.d(TAG, "SOURCE: FusedLocationClient - Coordinates: ${location.latitude}, ${location.longitude}")
                    callback(LatLng(location.latitude, location.longitude))
                } else {
                    Log.d(TAG, "FusedLocationClient returned null location, checking Firebase...")

                    val firebaseUser = FirebaseAuth.getInstance().currentUser
                    if (firebaseUser != null) {
                        Log.d(TAG, "Attempting to fetch location for user ${firebaseUser.uid} from Firebase...")
                        // Fetch user location from Firebase
                        FirebaseDatabase.getInstance().reference
                            .child("town")
                            .child(firebaseUser.uid)
                            .get()
                            .addOnSuccessListener { snapshot ->
                                val lat = snapshot.child("latitude").getValue(Double::class.java)
                                val lng = snapshot.child("longitude").getValue(Double::class.java)

                                if (lat != null && lng != null) {
                                    Log.d(TAG, "SOURCE: Firebase - Coordinates: $lat, $lng")
                                    callback(LatLng(lat, lng))
                                } else {
                                    Log.d(TAG, "SOURCE: Default - No location in Firebase, using default coordinates 0.0, 0.0")
                                    callback(LatLng(0.0, 0.0))
                                }
                            }
                            .addOnFailureListener { e ->
                                Log.e(TAG, "SOURCE: Default - Failed to get location from Firebase: ${e.message}, using default coordinates 0.0, 0.0")
                                callback(LatLng(0.0, 0.0))
                            }
                    } else {
                        Log.d(TAG, "SOURCE: Default - No user logged in, using default coordinates 0.0, 0.0")
                        callback(LatLng(0.0, 0.0))
                    }
                }
            }.addOnFailureListener { e ->
                Log.e(TAG, "SOURCE: Default - Failed to get last location: ${e.message}, using default coordinates 0.0, 0.0")
                callback(LatLng(0.0, 0.0))
            }
        } else {
            Log.d(TAG, "SOURCE: Default - Location permission not granted, using default coordinates 0.0, 0.0")
            callback(LatLng(0.0, 0.0))
        }
    }

    /**
     * Starts both notification services with the user's ID and location.
     */
    private fun startLocationAndMonitoring(userId: String, location: LatLng) {
        Log.d(TAG, "Starting monitoring for user $userId with coordinates: ${location.latitude}, ${location.longitude}")

        // Initialize the built-in notification service
        initializeNotificationService(userId, location)

        // Start the MapNotificationService
        mapNotificationService.startMonitoring(userId, location)
    }

    /**
     * Shows a dialog explaining why location permission is important for the app.
     */
    private fun showLocationPermissionExplanationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Location Permission Required")
            .setMessage("This app needs location access to show nearby taxis and provide accurate pickup services. Without this permission, some features will be limited.")
            .setPositiveButton("Try Again") { _, _ ->
                // Request the permission again
                locationPermissionRequest.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            .setNegativeButton("Continue Anyway") { dialog, _ ->
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }

    /**
     * Checks whether the location permission has already been granted.
     *
     * @return True if the permission is granted, false otherwise.
     */
    private fun isLocationPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Checks whether the notification permission has already been granted.
     * Always returns true for Android versions below 13 (Tiramisu).
     *
     * @return True if the permission is granted or not needed, false otherwise.
     */
    private fun isNotificationPermissionGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            // For versions below Android 13, notification permission is not required
            true
        }
    }

    /**
     * Requests notification permission for Android 13+ devices.
     */
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    NOTIFICATION_PERMISSION_CODE
                )
            }
        }
    }

    /**
     * Handles the result of the permission request.
     */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == NOTIFICATION_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Notification permission granted
                showToast("Notification permission granted!")
                checkUserAndStartMonitoring()
            } else {
                // Notification permission denied
                showToast("Notification permission denied!")
                mapNotificationService.showNotificationPermissionExplanationDialog(this)
                checkUserAndStartMonitoring()
            }
        }
    }

    /**
     * Displays a short toast message to the user.
     *
     * @param message The message to be displayed in the toast.
     */
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    /**
     * Initializes the notification service when user is authenticated and location is available
     *
     * @param userId The ID of the authenticated user
     * @param location The current location of the user
     */
    private fun initializeNotificationService(userId: String, location: LatLng) {
        Log.d(TAG, "Initializing notification service for user $userId with coordinates: ${location.latitude}, ${location.longitude}")
        // Initialize notification service through application instance
        (application as TaxiApplication).initNotificationService(userId, location)
    }

    /**
     * Updates the user's location in the notification service
     *
     * @param location The updated location of the user
     */
    private fun updateUserLocation(location: LatLng) {
        // Update location in notification service
        (application as TaxiApplication).updateUserLocation(location)

        // Also update location in the MapNotificationService
        mapNotificationService.updateUserLocation(location)
    }

    /**
     * Cleans up resources when the activity is destroyed
     */
    override fun onDestroy() {
        super.onDestroy()
        // Clean up notification service resources
        (application as TaxiApplication).cleanupNotificationService()

        // Clean up MapNotificationService resources
        mapNotificationService.stopMonitoring()
    }
}


// The following code sets up the navigation structure of the application using Jetpack Compose.

/**
 * AppNavigation sets up the navigation graph for the Taxi application.
 * It defines all the possible routes and the corresponding composable screens.
 */
@Composable
fun AppNavigation() {
    // Create a NavController to manage navigation between composable screens
    val navController = rememberNavController()

    // Create a SystemUiController to manipulate system UI elements like the status bar
    val systemUiController = rememberSystemUiController()

    // Determine whether to use dark icons based on the current theme
    val useDarkIcons = !isSystemInDarkTheme()

    // Apply the TaxiTheme to ensure consistent styling across the app
    TaxiTheme {
        // Use SideEffect to perform actions that have side effects, such as changing system UI colors
        SideEffect {
            // Set the navigation bar color to transparent and disable dark icons
            systemUiController.setNavigationBarColor(
                color = Color.Transparent,
                darkIcons = false,
                navigationBarContrastEnforced = false
            )
            // Set the status bar color to black
            systemUiController.setStatusBarColor(
                color = Color.Black
            )
        }

        // Add this LaunchedEffect to check user login status when the app launches
        LaunchedEffect(key1 = Unit) {
            checkUserLoginStatus(navController)
        }

        // Define the navigation host with the starting destination as the Login screen
        NavHost(navController = navController, startDestination = Route.LOGIN) {
            // Define composable destinations for each route
            composable(Route.LOGIN) { LoginScreen(navController) }
            composable(Route.HOME) { HomeScreen(navController) }
            composable(Route.PASSENGER) { PassengerScreen(navController) }
            composable(Route.DRIVER) { DriverScreen(navController) }
            composable(Route.TERMS_AND_CONDITIONS) { TermsAndConditionsScreen(navController) }
            composable(Route.SETTINGS) { SettingsScreen(navController) }

            // Define a list of map-related routes for both passenger and driver modes
            listOf(
                Route.PASSENGER_MAP1, Route.PASSENGER_MAP2,
                Route.DRIVER_MAP1, Route.DRIVER_MAP2
            ).forEach { route ->
                composable(route) {
                    // Navigate to the appropriate map screen based on the route
                    when (route) {
                        Route.PASSENGER_MAP1 -> PassengerMapScreenTown(navController)
                        Route.PASSENGER_MAP2 -> PassengerMapScreenLocal(navController)
                        Route.DRIVER_MAP1 -> DriverMapScreenTown(navController)
                        Route.DRIVER_MAP2 -> DriverMapScreenLocal(navController)
                    }
                }
            }
        }
    }
}

/**
 * Checks if a user is already logged in and navigates to the Home screen if they are.
 * This function is called when the app starts, allowing returning users to skip the login screen.
 */
fun checkUserLoginStatus(navController: NavController) {
    val currentUser = FirebaseAuth.getInstance().currentUser

    if (currentUser != null) {
        // User is logged in, navigate directly to home
        navController.navigate(Route.HOME) {
            // Clear the back stack so user can't go back to login
            popUpTo(Route.LOGIN) { inclusive = true }
        }
    }
    // If user is null, stay on the login screen
}

/**
 * Route object holds all the constant route names used in the navigation graph.
 * This ensures consistency and helps avoid typos in route names.
 */
object Route {
    const val LOGIN = "login"
    const val HOME = "home"
    const val PASSENGER = "passenger"
    const val DRIVER = "driver"
    const val PASSENGER_MAP1 = "passengerMapScreenTown"
    const val PASSENGER_MAP2 = "passengerMapScreenLocal"
    const val DRIVER_MAP1 = "driverMapScreenTown"
    const val DRIVER_MAP2 = "driverMapScreenLocal"
    const val TERMS_AND_CONDITIONS = "terms_and_conditions"
    const val SETTINGS = "settings"
}