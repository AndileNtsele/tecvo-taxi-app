// Define the package name for the component, organizing it within the project structure.
package com.example.taxi.components

// Import necessary Jetpack Compose and Material Design components and utilities.
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * A composable function that displays a password requirement with an icon indicating
 * whether the requirement is satisfied.
 *
 * @param text The description of the password requirement (e.g., "At least 8 characters").
 * @param satisfied A boolean indicating if the requirement is met.
 */
@Composable
fun PasswordRequirement(
    text: String,
    satisfied: Boolean
) {
    // Row layout arranges its children horizontally.
    Row(
        // Apply vertical padding of 4 density-independent pixels (dp) around the row.
        modifier = Modifier.padding(vertical = 4.dp),
        // Align children vertically to the center within the row.
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Display an icon based on whether the requirement is satisfied.
        Icon(
            // Choose the appropriate icon: a check circle for satisfied, cancel for not.
            imageVector = if (satisfied) Icons.Default.CheckCircle else Icons.Default.Cancel,
            // Provide a content description for accessibility purposes.
            contentDescription = if (satisfied) "Requirement satisfied" else "Requirement not satisfied",
            // Tint the icon with the primary color if satisfied, otherwise with the error color.
            tint = if (satisfied) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            // Set the size of the icon to 16 dp.
            modifier = Modifier.size(16.dp)
        )
        // Add horizontal spacing of 8 dp between the icon and the text.
        Spacer(Modifier.width(8.dp))
        // Display the requirement text.
        Text(
            text = text,
            // Use the bodySmall typography style from the current Material theme.
            style = MaterialTheme.typography.bodySmall,
            // Set the text color to primary if satisfied, otherwise to error color.
            color = if (satisfied) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )
    }
}
