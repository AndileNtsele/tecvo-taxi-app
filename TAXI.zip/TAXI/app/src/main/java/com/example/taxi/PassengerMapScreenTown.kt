package com.example.taxi

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.core.app.ActivityCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import androidx.window.layout.WindowMetricsCalculator
import com.example.taxi.ui.theme.*
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import androidx.compose.runtime.DisposableEffect
import com.example.taxi.NotificationManager
import com.example.taxi.utils.RadiusCircle
import android.content.Context
import androidx.compose.ui.graphics.toArgb
import com.google.maps.android.compose.Circle



// Helper function to calculate distance between two coordinates (in kilometers)
fun calculateDistance(point1: LatLng, point2: LatLng): Double {
    val lat1 = Math.toRadians(point1.latitude)
    val lon1 = Math.toRadians(point1.longitude)
    val lat2 = Math.toRadians(point2.latitude)
    val lon2 = Math.toRadians(point2.longitude)

    val dlat = lat2 - lat1
    val dlon = lon2 - lon1
    val a = sin(dlat / 2).pow(2) + cos(lat1) * cos(lat2) * sin(dlon / 2).pow(2)

    // Clamp the value of a to avoid numerical errors
    val clampedA = a.coerceIn(0.0, 1.0)
    val c = 2 * asin(sqrt(clampedA))
    val r = 6371.0 // Earth radius in kilometers
    return c * r
}

@Composable
fun CountBadge(count: Int, backgroundColor: Color) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(backgroundColor)
    ) {
        Text(
            text = count.toString(),
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun FlashingUserMarkerTown(
    location: LatLng,
    iconBitmapDescriptor: com.google.android.gms.maps.model.BitmapDescriptor,
    markerTitle: String = "Me"
) {
    val infiniteTransition = rememberInfiniteTransition(label = "markerPulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "markerAlpha"
    )
    Marker(
        state = MarkerState(position = location),
        icon = iconBitmapDescriptor,
        title = markerTitle,
        snippet = "I am blinking!",
        alpha = alpha
    )
}

@Composable
fun PassengerMapScreenTown(navController: NavController) {

    // Notify NotificationManager when entering/exiting map screen
    DisposableEffect(key1 = Unit) {
        // On entering screen
        NotificationManager.enterMapScreen("PassengerMapTown")

        // On exiting screen
        onDispose {
            NotificationManager.exitMapScreen("PassengerMapTown")
        }
    }
    // Get context and device metrics for responsive sizing
    val context = LocalContext.current
    val windowMetrics = remember {
        WindowMetricsCalculator.getOrCreate().computeCurrentWindowMetrics(context as Activity)
    }

    // Calculate screen dimensions in dp
    val density = LocalDensity.current
    val screenWidthDp = windowMetrics.bounds.width() / context.resources.displayMetrics.density
    val screenHeightDp = windowMetrics.bounds.height() / context.resources.displayMetrics.density

    // Log screen dimensions for debugging
    Log.d("Taxi", "Screen dimensions: ${screenWidthDp}dp x ${screenHeightDp}dp")

    // Pick the correct dimensions based on screen width
    val dimens = when {
        screenWidthDp < 400 -> PassengerMapScreenTownCompactSmallDimens
        screenWidthDp in 400f..500f -> PassengerMapScreenTownCompactMediumDimens
        screenWidthDp in 500f..600f -> PassengerMapScreenTownCompactDimens
        screenWidthDp in 600f..840f -> PassengerMapScreenTownMediumDimens
        else -> PassengerMapScreenTownExpandedDimens
    }

    // Extract dimension values for use throughout the composition
    val smallSpacing = dimens.smallSpacing
    val mediumSpacing = dimens.mediumSpacing
    val headerTextSize = dimens.headerTextSize
    val mapButtonTextSize = dimens.mapButtonTextSize
    val passengerImageSize = dimens.passengerImageSize
    val minibusImageSize = dimens.minibusImageSize
    val mapIconSize = dimens.mapIconSize
    val imageSize = dimens.imageSize
    val cornerRadius = dimens.cornerRadius
    val hybridTextPadding = dimens.hybridTextPadding
    val centerMapRoundedCornerShape = dimens.centerMapRoundedCornerShape
    val centerMapPadding = dimens.centerMapPadding
    val loadingIndicatorCornerRadius = dimens.loadingIndicatorCornerRadius
    val markerAlpha = dimens.markerAlpha
    val controlsBackgroundAlpha = dimens.controlsBackgroundAlpha
    val loadingBackgroundAlpha = dimens.loadingBackgroundAlpha
    val searchRadius = dimens.defaultSearchRadius
    val defaultMapZoom = dimens.defaultMapZoom

    // Set up coroutine scope for launching operations
    val coroutineScope = rememberCoroutineScope()

    // Initialize Maps
    com.google.android.gms.maps.MapsInitializer.initialize(context)

    // Location & permission states
    var currentLocation by remember { mutableStateOf<LatLng?>(null) }
    var hasPermission by remember { mutableStateOf(false) }
    var permissionDenied by remember { mutableStateOf(false) }

    // Firebase references
    val auth = FirebaseAuth.getInstance()
    val database = Firebase.database("https://taxiapp-8aecb-default-rtdb.firebaseio.com/")
    val passengertown = database.getReference("passengers/town")
    val drivertown = database.getReference("drivers/town")

    val currentUser = auth.currentUser
    val passengerId = currentUser?.uid
    val userRef = passengerId?.let { passengertown.child(it) }

    // Location services
    val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

    // Track locations of drivers and other passengers
    val driversLocations = remember { mutableStateListOf<LatLng>() }
    val passengerLocations = remember { mutableStateListOf<LatLng>() }

    // Count variables for nearby entities
    var nearbyPassengersCount by remember { mutableStateOf(0) }
    var nearbyDriversCount by remember { mutableStateOf(0) }

    // Screen state tracking
    var isScreenActive by remember { mutableStateOf(true) }
    var locationCallback: LocationCallback? by remember { mutableStateOf(null) }
    var firebaseListener: com.google.firebase.database.ValueEventListener? by remember { mutableStateOf(null) }

    // Back navigation animation states
    var showBackNavigation by remember { mutableStateOf(false) }
    val backNavAlpha = remember { androidx.compose.animation.core.Animatable(1f) }

    // Update passenger location function
    fun updatePassengerLocation(location: Location) {
        if (passengerId == null) {
            Log.e("Taxi", "Location Update: Unable to update - passenger ID is null")
            return
        }
        userRef?.onDisconnect()?.removeValue()

        val locationData = mapOf(
            "latitude" to location.latitude,
            "longitude" to location.longitude,
            "timestamp" to ServerValue.TIMESTAMP,
            "type" to "passenger",
            "destination" to "town"
        )

        Log.i("Taxi", "Location: Updated to ${location.latitude}, ${location.longitude}")

        userRef?.setValue(locationData)?.addOnSuccessListener {
            Log.i("Taxi", "Firebase: User location updated successfully")
        }?.addOnFailureListener { e ->
            Log.e("Taxi", "Firebase: Failed to update location - ${e.message}")
        }
    }

    // Function to update counts of nearby entities
    fun updateNearbyCounts() {
        currentLocation?.let { userLocation ->
            Log.i("Taxi", "NearbyCount: Calculating from ${userLocation.latitude}, ${userLocation.longitude}")

            // Count nearby passengers (excluding current user)
            val previousPassengerCount = nearbyPassengersCount

            nearbyPassengersCount = passengerLocations.count { passengerLocation ->
                val distance = calculateDistance(userLocation, passengerLocation)
                val withinRadius = distance <= searchRadius
                if (withinRadius) {
                    Log.d("Taxi", "NearbyCount: Passenger at ${passengerLocation.latitude}, ${passengerLocation.longitude} is ${String.format("%.2f", distance)}km - COUNTED")
                }
                withinRadius
            }

            // Log the current user separately
            Log.d("Taxi", "NearbyCount: Current user at ${userLocation.latitude}, ${userLocation.longitude} - NOT counted in nearby total")

            // Count nearby drivers
            val previousDriverCount = nearbyDriversCount
            nearbyDriversCount = driversLocations.count { driverLocation ->
                val distance = calculateDistance(userLocation, driverLocation)
                val withinRadius = distance <= searchRadius
                if (withinRadius) {
                    Log.d("Taxi", "NearbyCount: Driver at ${driverLocation.latitude}, ${driverLocation.longitude} is ${String.format("%.2f", distance)}km - COUNTED")
                }
                withinRadius
            }

            // Log the summary
            Log.i("Taxi", "NearbyCount: Found ${nearbyPassengersCount} passengers and ${nearbyDriversCount} drivers within ${searchRadius}km")

            // Log count changes
            if (previousPassengerCount != nearbyPassengersCount) {
                Log.i("Taxi", "NearbyCount: Passenger count changed: ${previousPassengerCount} → ${nearbyPassengersCount}")
            }

            if (previousDriverCount != nearbyDriversCount) {
                Log.i("Taxi", "NearbyCount: Driver count changed: ${previousDriverCount} → ${nearbyDriversCount}")
            }
        } ?: Log.w("Taxi", "NearbyCount: Cannot calculate - current location is null")
    }

    // Logout user function
    fun logoutUser() {
        passengerId?.let {
            Log.i("Taxi", "Auth: Logging out user $it")
            passengertown.child(it).removeValue().addOnSuccessListener {
                Log.i("Taxi", "Firebase: User location data removed successfully")
            }
        }
        FirebaseAuth.getInstance().signOut()
        Log.i("Taxi", "Auth: User signed out successfully")
    }

    // Permission request launcher
    val requestPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        hasPermission = isGranted
        permissionDenied = !isGranted
        if (isGranted) {
            Log.i("Taxi", "Permission: Location access granted")
        } else {
            Log.e("Taxi", "Permission: Location access denied")
        }
    }

    // Check permission on first composition
    LaunchedEffect(Unit) {
        Log.i("Taxi", "Lifecycle: PassengerMapTown screen initialized")
        when {
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED -> {
                hasPermission = true
                Log.i("Taxi", "Permission: Location access already granted")
            }
            else -> {
                Log.i("Taxi", "Permission: Requesting location permission")
                requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
    }

    // Listen for driver & passenger updates
    LaunchedEffect(Unit) {
        Log.i("Taxi", "Firebase: Setting up location data listeners")

        val driverListener = object : com.google.firebase.database.ValueEventListener {
            override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                Log.i("Taxi", "Firebase: Driver data updated - ${snapshot.childrenCount} records received")
                driversLocations.clear()
                for (child in snapshot.children) {
                    val lat = child.child("latitude").getValue(Double::class.java)
                    val lng = child.child("longitude").getValue(Double::class.java)
                    if (lat != null && lng != null) {
                        driversLocations.add(LatLng(lat, lng))
                        Log.d("Taxi", "Firebase: Driver location loaded: ${lat}, ${lng}")
                    } else {
                        Log.w("Taxi", "Firebase: Driver ${child.key} has incomplete location data")
                    }
                }
                Log.i("Taxi", "Firebase: Loaded ${driversLocations.size} driver locations")
                updateNearbyCounts()
            }
            override fun onCancelled(error: com.google.firebase.database.DatabaseError) {
                Log.e("Taxi", "Firebase: Error fetching driver data - ${error.message}")
            }
        }

        val passengerListener = object : com.google.firebase.database.ValueEventListener {
            override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                Log.i("Taxi", "Firebase: Passenger data updated - ${snapshot.childrenCount} records received")
                passengerLocations.clear()
                for (child in snapshot.children) {
                    if (child.key != passengerId) {
                        val lat = child.child("latitude").getValue(Double::class.java)
                        val lng = child.child("longitude").getValue(Double::class.java)
                        if (lat != null && lng != null) {
                            passengerLocations.add(LatLng(lat, lng))
                            Log.d("Taxi", "Firebase: Other passenger location loaded: ${lat}, ${lng}")
                        } else {
                            Log.w("Taxi", "Firebase: Passenger ${child.key} has incomplete location data")
                        }
                    } else {
                        // Log the current user's data from Firebase
                        val lat = child.child("latitude").getValue(Double::class.java)
                        val lng = child.child("longitude").getValue(Double::class.java)
                        Log.d("Taxi", "Firebase: Current user data confirmed in database: ${lat}, ${lng}")
                    }
                }
                Log.i("Taxi", "Firebase: Loaded ${passengerLocations.size} other passenger locations")
                updateNearbyCounts()
            }
            override fun onCancelled(error: com.google.firebase.database.DatabaseError) {
                Log.e("Taxi", "Firebase: Error fetching passenger data - ${error.message}")
            }
        }

        drivertown.addValueEventListener(driverListener)
        passengertown.addValueEventListener(passengerListener)

        // Store references for cleanup
        firebaseListener = driverListener

        Log.i("Taxi", "Firebase: Data listeners setup complete")
    }

    // One-time last known location
    LaunchedEffect(hasPermission) {
        if (hasPermission && passengerId != null) {
            Log.i("Taxi", "Location: Requesting last known location")
            try {
                if (ActivityCompat.checkSelfPermission(
                        context,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    fusedLocationClient.lastLocation.addOnSuccessListener { loc: Location? ->
                        if (loc != null) {
                            Log.i("Taxi", "Location: Last known position is ${loc.latitude}, ${loc.longitude}")
                            currentLocation = LatLng(loc.latitude, loc.longitude)
                            updatePassengerLocation(loc)
                            updateNearbyCounts()
                        } else {
                            Log.w("Taxi", "Location: Last known position unavailable")
                        }
                    }.addOnFailureListener { e ->
                        Log.e("Taxi", "Location: Failed to get last position - ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e("Taxi", "Location: Error accessing location - ${e.message}")
            }
        }
    }

    // Continuous location updates
    LaunchedEffect(hasPermission) {
        if (hasPermission && passengerId != null && isScreenActive) {
            Log.i("Taxi", "Location: Starting continuous position tracking")
            val locationRequest = LocationRequest.create().apply {
                priority = LocationRequest.PRIORITY_HIGH_ACCURACY
                interval = 10_000
                fastestInterval = 5_000
            }
            locationCallback = object : LocationCallback() {
                override fun onLocationResult(locationResult: LocationResult) {
                    if (isScreenActive) {
                        locationResult.lastLocation?.let { loc ->
                            Log.i("Taxi", "Location: Position updated to ${loc.latitude}, ${loc.longitude}")
                            currentLocation = LatLng(loc.latitude, loc.longitude)
                            updatePassengerLocation(loc)
                            updateNearbyCounts()
                        } ?: Log.w("Taxi", "Location: Update received but position data is null")
                    }
                }
            }
            try {
                if (ActivityCompat.checkSelfPermission(
                        context,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    locationCallback?.let { callback ->
                        Log.i("Taxi", "Location: Registering for position updates")
                        fusedLocationClient.requestLocationUpdates(
                            locationRequest,
                            callback,
                            context.mainLooper
                        )
                    }
                } else {
                    Log.e("Taxi", "Location: Unable to start tracking - permission denied")
                }
            } catch (e: Exception) {
                Log.e("Taxi", "Location: Error setting up location updates - ${e.message}")
            }
        }
    }

    // Back navigation hint animation
    LaunchedEffect(Unit) {
        delay(4000) // Delay before showing
        showBackNavigation = true
        Log.d("Taxi", "UI: Showing back navigation hint")
        delay(3000) // Show for 3 seconds
        backNavAlpha.animateTo(0f, animationSpec = tween(1000)) // Fade out
        showBackNavigation = false
        Log.d("Taxi", "UI: Hiding back navigation hint")
    }

    // Cleanup on dispose
    DisposableEffect(Unit) {
        onDispose {
            isScreenActive = false
            Log.i("Taxi", "Lifecycle: PassengerMapTown screen disposed")

            try {
                locationCallback?.let {
                    fusedLocationClient.removeLocationUpdates(it)
                    Log.i("Taxi", "Location: Position tracking stopped")
                }

                passengerId?.let { id ->
                    Log.i("Taxi", "Firebase: Removing user $id from database")
                    passengertown.child(id).removeValue()
                        .addOnFailureListener { e ->
                            Log.e("Taxi", "Firebase: Failed to remove user data - ${e.message}")
                        }
                        .addOnSuccessListener {
                            Log.i("Taxi", "Firebase: User data successfully removed")
                        }
                }

                if (firebaseListener != null) {
                    Log.i("Taxi", "Firebase: Removing data listeners")
                    drivertown.removeEventListener(firebaseListener!!)
                    passengertown.removeEventListener(firebaseListener!!)
                } else {
                    Log.w("Taxi", "Firebase: No data listeners to remove")
                }
            } catch (e: Exception) {
                Log.e("Taxi", "Cleanup: Error during cleanup - ${e.message}")
            }
        }
    }

    // Camera position state
    val cameraPositionState = rememberCameraPositionState()
    LaunchedEffect(currentLocation) {
        currentLocation?.let { latLng ->
            Log.i("Taxi", "Map: Moving camera to ${latLng.latitude}, ${latLng.longitude} at zoom $defaultMapZoom")
            cameraPositionState.animate(
                CameraUpdateFactory.newCameraPosition(
                    CameraPosition.fromLatLngZoom(latLng, defaultMapZoom)
                )
            )
        }
    }

    // Map properties
    val mapProperties = remember {
        mutableStateOf(
            MapProperties(
                mapType = MapType.NORMAL,
                isMyLocationEnabled = false
            )
        )
    }

    // Create a remembered BitmapDescriptor for the current user icon
    val userMarkerBitmapDescriptor = remember {
        val sizePx = (density.density * imageSize.value).toInt()
        BitmapDescriptorFactory.fromBitmap(
            context.getDrawable(R.drawable.passenger1)?.toBitmap(sizePx, sizePx)!!
        )
    }

    // Loading state
    var isLoading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(2000)
        isLoading = false
        Log.i("Taxi", "Map: Loading completed")
    }

    // ----------------------------------
    // Main UI Layout with proper system bars handling
    // ----------------------------------
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF0A1F44), // Dark blue at the top
                        Color(0xFF16294B)  // Slightly lighter blue at the bottom
                    )
                )
            )
    ) {
        // Main content with safe drawing area
        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Passenger icon with count badge to the right (inner side)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.passenger1),
                            contentDescription = "Passenger Left",
                            modifier = Modifier.size(passengerImageSize)
                        )
                        // Count badge on inner side (right of passenger icon) - only visible if count > 0
                        if (nearbyPassengersCount > 0) {
                            CountBadge(
                                count = nearbyPassengersCount,
                                backgroundColor = Color(0xFF4CAF50) // Green for passengers
                            )
                        }
                    }

                    // Center text section
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Town",
                            color = Color.White,
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontSize = headerTextSize,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    // Minibus icon with count badge to the left (inner side)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        // Count badge on inner side (left of minibus icon) - only visible if count > 0
                        if (nearbyDriversCount > 0) {
                            CountBadge(
                                count = nearbyDriversCount,
                                backgroundColor = Color(0xFF2196F3) // Blue for drivers/taxis
                            )
                        }
                        Image(
                            painter = painterResource(id = R.drawable.minibus1),
                            contentDescription = "Minibus Right",
                            modifier = Modifier.size(minibusImageSize)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(mediumSpacing))

                // Map section - expanded to fill the entire remaining space
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f) // Map takes up all remaining vertical space
                ) {
                    if (isLoading) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Color.Black.copy(alpha = loadingBackgroundAlpha),
                                    RoundedCornerShape(loadingIndicatorCornerRadius)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = Color.White)
                        }
                    } else {
                        // Load notification radius from SharedPreferences
                        val context = LocalContext.current
                        val sharedPrefs = context.getSharedPreferences("taxi_app_prefs", Context.MODE_PRIVATE)
                        val notificationRadiusKm = sharedPrefs.getFloat("notification_radius_km", 2.0f)

                        // Log the notification radius value
                        Log.d("Taxi", "Loading notification radius: $notificationRadiusKm km")

                        GoogleMap(
                            modifier = Modifier.fillMaxSize(),
                            cameraPositionState = cameraPositionState,
                            properties = mapProperties.value,
                            uiSettings = remember {
                                MapUiSettings(
                                    zoomControlsEnabled = true,
                                    zoomGesturesEnabled = true,
                                    scrollGesturesEnabled = true,
                                    compassEnabled = true
                                )
                            }
                        ) {
                            // Current user location with radius circle
                            currentLocation?.let { loc ->
                                // Log before drawing the circle
                                Log.d("Taxi", "Drawing radius circle: center=(${loc.latitude}, ${loc.longitude}), radius=$notificationRadiusKm km")

                                // Draw radius circle first (underneath the marker)
                                Circle(
                                    center = loc,
                                    radius = notificationRadiusKm * 1000.0, // Convert km to meters
                                    fillColor = Color(0x1A4CAF50),  // Light green (10% opacity) for passenger
                                    strokeColor = Color(0x4D4CAF50),  // Green border (30% opacity)
                                    strokeWidth = 2f
                                )

                                // Log after drawing the circle
                                Log.d("Taxi", "Radius circle drawn successfully with radius: ${notificationRadiusKm * 1000.0} meters")

                                // Then draw the user marker on top
                                FlashingUserMarkerTown(
                                    location = loc,
                                    iconBitmapDescriptor = userMarkerBitmapDescriptor,
                                    markerTitle = "My Location"
                                )
                            }

                            // Other passengers
                            passengerLocations.forEach { loc ->
                                val sizePx = (density.density * imageSize.value).toInt()
                                Marker(
                                    state = MarkerState(position = loc),
                                    icon = BitmapDescriptorFactory.fromBitmap(
                                        context.getDrawable(R.drawable.passenger1)
                                            ?.toBitmap(sizePx, sizePx)!!
                                    ),
                                    title = "Passenger",
                                    snippet = "Other passenger going to town",
                                    alpha = markerAlpha
                                )
                            }

                            // Drivers
                            driversLocations.forEach { loc ->
                                val sizePx = (density.density * imageSize.value).toInt()
                                Marker(
                                    state = MarkerState(position = loc),
                                    icon = BitmapDescriptorFactory.fromBitmap(
                                        context.getDrawable(R.drawable.minibus3)
                                            ?.toBitmap(sizePx, sizePx)!!
                                    ),
                                    title = "Taxi",
                                    snippet = "Available taxi to town",
                                    alpha = markerAlpha
                                )
                            }
                        }

                        // Map type toggle and center controls
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = smallSpacing, start = 10.dp, end = 10.dp, bottom = 0.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Hybrid toggle (left corner)
                            Box(
                                modifier = Modifier
                                    .background(
                                        Color.White.copy(alpha = 0.9f),
                                        shape = RoundedCornerShape(cornerRadius)
                                    )
                                    .padding(hybridTextPadding)
                            ) {
                                val buttonText = if (mapProperties.value.mapType == MapType.NORMAL)
                                    "Hybrid" else "Normal"
                                Text(
                                    text = buttonText,
                                    modifier = Modifier
                                        .clickable {
                                            mapProperties.value = mapProperties.value.copy(
                                                mapType = if (mapProperties.value.mapType == MapType.NORMAL)
                                                    MapType.HYBRID else MapType.NORMAL
                                            )
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    color = Color.Black,
                                    fontSize = mapButtonTextSize,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Re-center map button (right corner)
                            Box(
                                modifier = Modifier
                                    .size(mapIconSize)
                                    .background(
                                        Color.White.copy(alpha = 0.9f),
                                        shape = RoundedCornerShape(centerMapRoundedCornerShape)
                                    )
                                    .padding(centerMapPadding)
                                    .clickable {
                                        coroutineScope.launch {
                                            currentLocation?.let {
                                                cameraPositionState.animate(
                                                    CameraUpdateFactory.newCameraPosition(
                                                        CameraPosition.fromLatLngZoom(it, defaultMapZoom)
                                                    )
                                                )
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    painter = painterResource(id = R.drawable.currentlocation),
                                    contentDescription = "Re-center Map",
                                    tint = Color.Unspecified,
                                    modifier = Modifier.size(mapIconSize * 0.8f)
                                )
                            }
                        }
                    }
                }
            }

            // Back navigation animation
            AnimatedVisibility(
                visible = showBackNavigation,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 8.dp),
                enter = slideInHorizontally(initialOffsetX = { -it }),
                exit = slideOutHorizontally(targetOffsetX = { -it }) + fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            Color.White.copy(alpha = 0.8f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = ImageVector.vectorResource(id = R.drawable.fingerpointer),
                            contentDescription = "Back",
                            tint = Color(0xFF0D4C54),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Click here to go back",
                            color = Color(0xFF0D4C54),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Transparent clickable area with high z-index
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(40.dp) // Adjust width as needed
                    .align(Alignment.CenterStart)
                    .zIndex(100f) // Very high z-index to ensure it's on top
                    .background(Color.Transparent) // Make it invisible
                    .clickable {
                        navController.navigate("home")
                    }
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PassengerMapScreenTownPreview() {
    PassengerMapScreenTown(navController = rememberNavController())
}