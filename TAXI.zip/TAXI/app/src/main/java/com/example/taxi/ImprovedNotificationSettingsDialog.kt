package com.example.taxi

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

@Composable
fun ImprovedNotificationSettingsDialog(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    sharedPrefs: android.content.SharedPreferences
) {
    if (!showDialog) return

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Load notification preferences
    var passengersNotificationsEnabled by remember {
        mutableStateOf(sharedPrefs.getBoolean("notify_passengers", false))
    }

    var driversNotificationsEnabled by remember {
        mutableStateOf(sharedPrefs.getBoolean("notify_drivers", false))
    }

    var proximityNotificationsEnabled by remember {
        mutableStateOf(sharedPrefs.getBoolean("notify_proximity", false))
    }

    var backgroundNotificationsEnabled by remember {
        mutableStateOf(sharedPrefs.getBoolean("allow_background_notifications", false))
    }

    var notificationRadius by remember {
        mutableStateOf(sharedPrefs.getFloat("notification_radius_km", 2.0f).toString())
    }

    // If both notification types are disabled, also disable proximity notifications
    LaunchedEffect(passengersNotificationsEnabled, driversNotificationsEnabled) {
        if (!passengersNotificationsEnabled && !driversNotificationsEnabled) {
            proximityNotificationsEnabled = false
        }
    }

    // Function to save notification preferences
    fun saveNotificationPreferences() {
        // Validation: If proximity is enabled, ensure at least one notification type is selected
        if (proximityNotificationsEnabled && !passengersNotificationsEnabled && !driversNotificationsEnabled) {
            proximityNotificationsEnabled = false
            Toast.makeText(
                context,
                "Proximity notifications require at least one notification type to be enabled",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val radiusInKm = notificationRadius.toFloatOrNull() ?: 2.0f

        with(sharedPrefs.edit()) {
            putBoolean("notify_passengers", passengersNotificationsEnabled)
            putBoolean("notify_drivers", driversNotificationsEnabled)
            putBoolean("notify_proximity", proximityNotificationsEnabled)
            putFloat("notification_radius_km", radiusInKm)
            putBoolean("allow_background_notifications", backgroundNotificationsEnabled)
            apply()
        }

        // If the user is logged in, also save preferences to Firebase
        val user = FirebaseAuth.getInstance().currentUser
        user?.uid?.let { userId ->
            val database = Firebase.database("https://taxiapp-8aecb-default-rtdb.firebaseio.com/")
            val userPrefsRef = database.getReference("user_preferences/$userId")

            val userPrefs = mapOf(
                "notify_passengers" to passengersNotificationsEnabled,
                "notify_drivers" to driversNotificationsEnabled,
                "notify_proximity" to proximityNotificationsEnabled,
                "notification_radius_km" to radiusInKm,
                "allow_background_notifications" to backgroundNotificationsEnabled
            )

            userPrefsRef.setValue(userPrefs)
        }

        // Update the active notification service with new preferences
        (context.applicationContext as TaxiApplication).updateNotificationServicePreferences()

        Toast.makeText(context, "Notification settings saved", Toast.LENGTH_SHORT).show()
        onDismiss()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f), // Cap the dialog height
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Scrollable content area
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(scrollState)
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header
                    Text(
                        text = "Notification Settings",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 22.sp
                        )
                    )

                    Text(
                        "Choose what notifications you want to receive",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Notification type section - simple toggles
                    NotificationToggleRow(
                        title = "Passenger notifications",
                        checked = passengersNotificationsEnabled,
                        onCheckedChange = {
                            passengersNotificationsEnabled = it
                            if (!it && !driversNotificationsEnabled) {
                                proximityNotificationsEnabled = false
                            }
                        }
                    )

                    NotificationToggleRow(
                        title = "Driver notifications",
                        checked = driversNotificationsEnabled,
                        onCheckedChange = {
                            driversNotificationsEnabled = it
                            if (!it && !passengersNotificationsEnabled) {
                                proximityNotificationsEnabled = false
                            }
                        }
                    )

                    Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // Delivery options section - toggles with descriptions
                    NotificationToggleWithDescription(
                        title = "Only notify when nearby",
                        description = "You'll only receive notifications about vehicles/passengers within your defined radius",
                        checked = proximityNotificationsEnabled,
                        onCheckedChange = { newValue ->
                            if (newValue && !passengersNotificationsEnabled && !driversNotificationsEnabled) {
                                Toast.makeText(
                                    context,
                                    "Enable at least one notification type first",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                proximityNotificationsEnabled = newValue
                            }
                        },
                        enabled = passengersNotificationsEnabled || driversNotificationsEnabled
                    )

                    NotificationToggleWithDescription(
                        title = "Receive notifications when app is closed",
                        description = "Get notified of new passengers/drivers even when not using the app",
                        checked = backgroundNotificationsEnabled,
                        onCheckedChange = { backgroundNotificationsEnabled = it },
                        enabled = passengersNotificationsEnabled || driversNotificationsEnabled
                    )

                    // Notification radius section (only shown if proximity notifications are enabled)
                    AnimatedVisibility(
                        visible = proximityNotificationsEnabled,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                            Text(
                                "Notification radius (km)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Medium
                            )

                            // Radius input field
                            OutlinedTextField(
                                value = notificationRadius,
                                onValueChange = {
                                    // Only allow numeric input and decimal point
                                    if (it.isEmpty() || it.all { char -> char.isDigit() || char == '.' }) {
                                        notificationRadius = it
                                    }
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                trailingIcon = {
                                    Text(
                                        "km",
                                        modifier = Modifier.padding(end = 16.dp),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                shape = RoundedCornerShape(12.dp)
                            )

                            // Info text
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )

                                Text(
                                    "Default distance is 2km. You can decrease or increase this distance.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Distance chip options
                            Text(
                                "Quick select",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                            )

                            // First row of distance options
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                DistanceChip(
                                    text = "2km",
                                    selected = notificationRadius == "2",
                                    onClick = { notificationRadius = "2" }
                                )
                                DistanceChip(
                                    text = "5km",
                                    selected = notificationRadius == "5",
                                    onClick = { notificationRadius = "5" }
                                )
                                DistanceChip(
                                    text = "10km",
                                    selected = notificationRadius == "10",
                                    onClick = { notificationRadius = "10" }
                                )
                            }

                            // Second row of distance options
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                DistanceChip(
                                    text = "20km",
                                    selected = notificationRadius == "20",
                                    onClick = { notificationRadius = "20" }
                                )
                                DistanceChip(
                                    text = "35km",
                                    selected = notificationRadius == "35",
                                    onClick = { notificationRadius = "35" }
                                )
                                DistanceChip(
                                    text = "50km",
                                    selected = notificationRadius == "50",
                                    onClick = { notificationRadius = "50" }
                                )
                            }
                        }
                    }
                }

                // Action buttons in a fixed bottom bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Cancel button
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    ) {
                        Text("Cancel")
                    }

                    // Save button
                    Button(
                        onClick = { saveNotificationPreferences() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text("Save")
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            color = if (enabled)
                MaterialTheme.colorScheme.onSurface
            else
                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
        )

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            modifier = Modifier.padding(vertical = 4.dp)
        )
    }
}

@Composable
fun NotificationToggleWithDescription(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true
) {
    val alpha by animateFloatAsState(targetValue = if (enabled) 1f else 0.6f)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .alpha(alpha),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun DistanceChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val backgroundColor = if (selected)
        MaterialTheme.colorScheme.primaryContainer
    else
        MaterialTheme.colorScheme.surface

    val textColor = if (selected)
        MaterialTheme.colorScheme.onPrimaryContainer
    else
        MaterialTheme.colorScheme.onSurface

    val borderColor = if (selected)
        MaterialTheme.colorScheme.primaryContainer
    else
        MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)

    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .border(
                width = 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(24.dp)
            ),
        color = backgroundColor,
        shape = RoundedCornerShape(24.dp),
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = textColor,
                fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal
            )
        }
    }
}