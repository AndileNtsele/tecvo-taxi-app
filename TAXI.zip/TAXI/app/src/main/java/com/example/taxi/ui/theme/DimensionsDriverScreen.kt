// DimensionsDriverScreen.kt
package com.example.taxi.ui.theme

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Dimensions specific to the DriverScreen.
 *
 * This data class holds all the adjustable values organized to follow
 * the top-to-bottom flow of the UI layout for the DriverScreen composable.
 */
data class DriverScreenDimens(
    // ===== LAYOUT & SPACING =====
    /** Overall screen padding around the main content */
    val screenPadding: Dp,
    /** Small spacer height for minimal gaps between elements */
    val smallSpacerHeight: Dp,

    // ===== APP LOGO SECTION =====
    /** Size of the app logo image (width and height) */
    val logoImageSize: Dp,
    /** Padding below the app logo */
    val appLogoPadding: Dp,
    /** Spacer height after the app logo */
    val appLogoSpacerHeight: Dp,

    // ===== DRIVER IMAGE SECTION =====
    /** Size for the driver/minibus image */
    val driverImageSize: Dp,
    /** Padding around the driver image */
    val imagePadding: Dp,
    /** Spacer height after the driver image */
    val imageSpacerHeight: Dp,

    // ===== BUTTON SECTION =====
    /** Width of all buttons (Town, Local, Home) */
    val buttonWidth: Dp,
    /** Height of all buttons */
    val buttonHeight: Dp,
    /** Corner radius for the buttons */
    val cornerRadius: Dp,
    /** Spacer height between buttons */
    val buttonSpacerHeight: Dp,

    // ===== TEXT =====
    /** Font size for button labels (Town, Local, Home) */
    val labelTextSize: TextUnit,

    // ===== VISUAL EFFECTS =====
    /** Background image opacity (0.0f to 1.0f) */
    val backgroundAlpha: Float
)

/**
 * 1) DriverScreenCompactSmallDimens:
 *    For very small devices (width < 400dp).
 */
val DriverScreenCompactSmallDimens = DriverScreenDimens(
    // Layout & Spacing
    screenPadding = 16.dp,                // Overall padding around screen content
    smallSpacerHeight = 20.dp,            // Small spacer between elements (e.g., at bottom of screen)

    // App Logo Section
    logoImageSize = 200.dp,               // Size of app logo (200×200dp square)
    appLogoPadding = 10.dp,               // Padding below the app logo
    appLogoSpacerHeight = 14.dp,          // Space between logo and other elements

    // Driver Image Section
    driverImageSize = 100.dp,             // Size of driver/minibus image
    imagePadding = 10.dp,                 // Padding around driver image
    imageSpacerHeight = 18.dp,            // Space after driver image

    // Button Section
    buttonWidth = 340.dp,                 // Width for Town, Local and Home buttons
    buttonHeight = 65.dp,                 // Height for Town, Local and Home buttons
    cornerRadius = 25.dp,                 // Corner radius for buttons
    buttonSpacerHeight = 30.dp,           // Space between buttons

    // Text
    labelTextSize = 20.sp,                // Font size for button labels

    // Visual Effects
    backgroundAlpha = 0.8f                // Background image opacity
)

/**
 * 2) DriverScreenCompactMediumDimens:
 *    For small to medium devices (400dp <= width < 500dp).
 */
val DriverScreenCompactMediumDimens = DriverScreenDimens(
    // Layout & Spacing
    screenPadding = 16.dp,                // Overall padding around screen content
    smallSpacerHeight = 20.dp,            // Small spacer between elements (e.g., at bottom of screen)

    // App Logo Section
    logoImageSize = 200.dp,               // Size of app logo (200×200dp square)
    appLogoPadding = 10.dp,               // Padding below the app logo
    appLogoSpacerHeight = 100.dp,         // Space between logo and other elements

    // Driver Image Section
    driverImageSize = 100.dp,             // Size of driver/minibus image
    imagePadding = 10.dp,                 // Padding around driver image
    imageSpacerHeight = 18.dp,            // Space after driver image

    // Button Section
    buttonWidth = 340.dp,                 // Width for Town, Local and Home buttons
    buttonHeight = 65.dp,                 // Height for Town, Local and Home buttons
    cornerRadius = 8.dp,                  // Corner radius for buttons
    buttonSpacerHeight = 30.dp,           // Space between buttons

    // Text
    labelTextSize = 20.sp,                // Font size for button labels

    // Visual Effects
    backgroundAlpha = 0.8f                // Background image opacity
)

/**
 * 3) DriverScreenCompactDimens:
 *    For typical larger phones (500dp <= width < 600dp).
 */
val DriverScreenCompactDimens = DriverScreenDimens(
    // Layout & Spacing
    screenPadding = 20.dp,                // Overall padding around screen content
    smallSpacerHeight = 20.dp,            // Small spacer between elements (e.g., at bottom of screen)

    // App Logo Section
    logoImageSize = 200.dp,               // Size of app logo (200×200dp square)
    appLogoPadding = 10.dp,               // Padding below the app logo
    appLogoSpacerHeight = 14.dp,          // Space between logo and other elements

    // Driver Image Section
    driverImageSize = 100.dp,             // Size of driver/minibus image
    imagePadding = 10.dp,                 // Padding around driver image
    imageSpacerHeight = 18.dp,            // Space after driver image

    // Button Section
    buttonWidth = 340.dp,                 // Width for Town, Local and Home buttons
    buttonHeight = 65.dp,                 // Height for Town, Local and Home buttons
    cornerRadius = 25.dp,                 // Corner radius for buttons
    buttonSpacerHeight = 30.dp,           // Space between buttons

    // Text
    labelTextSize = 20.sp,                // Font size for button labels

    // Visual Effects
    backgroundAlpha = 0.8f                // Background image opacity
)

/**
 * 4) DriverScreenMediumDimens:
 *    For small tablets or larger phones in landscape (600dp <= width < 840dp).
 */
val DriverScreenMediumDimens = DriverScreenDimens(
    // Layout & Spacing
    screenPadding = 24.dp,                // Overall padding around screen content
    smallSpacerHeight = 20.dp,            // Small spacer between elements (e.g., at bottom of screen)

    // App Logo Section
    logoImageSize = 200.dp,               // Size of app logo (200×200dp square)
    appLogoPadding = 10.dp,               // Padding below the app logo
    appLogoSpacerHeight = 14.dp,          // Space between logo and other elements

    // Driver Image Section
    driverImageSize = 100.dp,             // Size of driver/minibus image
    imagePadding = 10.dp,                 // Padding around driver image
    imageSpacerHeight = 18.dp,            // Space after driver image

    // Button Section
    buttonWidth = 340.dp,                 // Width for Town, Local and Home buttons
    buttonHeight = 65.dp,                 // Height for Town, Local and Home buttons
    cornerRadius = 25.dp,                 // Corner radius for buttons
    buttonSpacerHeight = 30.dp,           // Space between buttons

    // Text
    labelTextSize = 20.sp,                // Font size for button labels

    // Visual Effects
    backgroundAlpha = 0.8f                // Background image opacity
)

/**
 * 5) DriverScreenExpandedDimens:
 *    For larger tablets or desktop-style layouts (width >= 840dp).
 */
val DriverScreenExpandedDimens = DriverScreenDimens(
    // Layout & Spacing
    screenPadding = 28.dp,                // Overall padding around screen content
    smallSpacerHeight = 16.dp,            // Small spacer between elements (e.g., at bottom of screen)

    // App Logo Section
    logoImageSize = 120.dp,               // Size of app logo (120×120dp square)
    appLogoPadding = 16.dp,               // Padding below the app logo
    appLogoSpacerHeight = 20.dp,          // Space between logo and other elements

    // Driver Image Section
    driverImageSize = 160.dp,             // Size of driver/minibus image
    imagePadding = 16.dp,                 // Padding around driver image
    imageSpacerHeight = 24.dp,            // Space after driver image

    // Button Section
    buttonWidth = 340.dp,                 // Width for Town, Local and Home buttons
    buttonHeight = 65.dp,                 // Height for Town, Local and Home buttons
    cornerRadius = 16.dp,                 // Corner radius for buttons
    buttonSpacerHeight = 20.dp,           // Space between buttons

    // Text
    labelTextSize = 24.sp,                // Font size for button labels

    // Visual Effects
    backgroundAlpha = 0.8f                // Background image opacity
)