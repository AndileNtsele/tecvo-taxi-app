@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.taxi

import android.app.Activity
import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import androidx.window.layout.WindowMetricsCalculator
import com.example.taxi.ui.theme.*
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.tasks.await

/**
 * PassengerScreen composable function displays the main screen for passenger mode.
 *
 * @param navController Navigation controller for screen transitions
 */
@Composable
fun PassengerScreen(navController: NavController) {
    // Get current context and determine screen width for responsive design
    val context = LocalContext.current as? Activity ?: return
    val dimens = rememberResponsiveDimensions(context)

    // State holder for location
    val location = remember { mutableStateOf<Location?>(null) }

    // Fetch current location once on screen load
    LaunchedEffect(Unit) {
        location.value = getCurrentLocationSuspend(context)
    }

    // Root Box container for the whole screen
    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Background image with reduced opacity
        Image(
            painter = painterResource(id = R.drawable.background_image),
            contentDescription = null, // Background doesn't need accessibility description
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = dimens.backgroundAlpha
        )

        // Gradient overlay on top of the image for better contrast
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF0A1F44).copy(alpha = 0.85f),
                            Color(0xFF16294B).copy(alpha = 0.85f)
                        )
                    )
                )
        )

        // Main content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(dimens.screenPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(dimens.appLogoSpacerHeight))

            // App logo
            Image(
                painter = painterResource(id = R.drawable.applogo),
                contentDescription = "App Logo",
                modifier = Modifier
                    .size(dimens.logoImageSize)
                    .padding(bottom = dimens.appLogoPadding),
                contentScale = ContentScale.Fit
            )

            Spacer(modifier = Modifier.height(dimens.appLogoSpacerHeight))

            // Passenger image
            Image(
                painter = painterResource(id = R.drawable.passenger1),
                contentDescription = "Passenger Icon",
                modifier = Modifier
                    .size(dimens.passengerImageSize)
                    .padding(dimens.imagePadding),
                contentScale = ContentScale.Fit
            )

            Spacer(modifier = Modifier.height(dimens.imageSpacerHeight))

            // Navigation buttons
            NavigationButton(
                text = "Town",
                onClick = { navController.navigate("PassengerMapScreenTown") },
                dimens = dimens
            )

            Spacer(modifier = Modifier.height(dimens.buttonSpacerHeight))

            NavigationButton(
                text = "Local",
                onClick = { navController.navigate("PassengerMapScreenLocal") },
                dimens = dimens
            )

            Spacer(modifier = Modifier.height(dimens.buttonSpacerHeight))

            NavigationButton(
                text = "Home",
                onClick = { navController.navigate("home") },
                dimens = dimens
            )

            Spacer(modifier = Modifier.height(dimens.smallSpacerHeight))
        }
    }
}

/**
 * Reusable button composable for navigation actions.
 */
@Composable
private fun NavigationButton(
    text: String,
    onClick: () -> Unit,
    dimens: PassengerScreenDimens
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .width(dimens.buttonWidth)
            .height(dimens.buttonHeight),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.White,
            contentColor = Color.Black
        ),
        shape = RoundedCornerShape(dimens.cornerRadius)
    ) {
        Text(text = text, fontSize = dimens.labelTextSize)
    }
}

/**
 * Remember the dimensions based on screen width for better performance.
 */
@Composable
private fun rememberResponsiveDimensions(context: Activity): PassengerScreenDimens {
    val windowMetrics = remember {
        WindowMetricsCalculator.getOrCreate().computeCurrentWindowMetrics(context)
    }

    val screenWidthDp = windowMetrics.bounds.width() / context.resources.displayMetrics.density

    return remember(screenWidthDp) {
        when {
            screenWidthDp < 400f -> PassengerScreenCompactSmallDimens
            screenWidthDp in 400f..500f -> PassengerScreenCompactMediumDimens
            screenWidthDp in 500f..600f -> PassengerScreenCompactDimens
            screenWidthDp in 600f..840f -> PassengerScreenMediumDimens
            else -> PassengerScreenExpandedDimens
        }
    }
}

/**
 * Suspending function to fetch current location using coroutines.
 */
@SuppressLint("MissingPermission")
private suspend fun getCurrentLocationSuspend(context: Context): Location? {
    val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    return try {
        fusedLocationClient.lastLocation.await()
    } catch (e: Exception) {
        null
    }
}

@Preview(showBackground = true)
@Composable
fun PassengerScreenPreview() {
    PassengerScreen(navController = rememberNavController())
}