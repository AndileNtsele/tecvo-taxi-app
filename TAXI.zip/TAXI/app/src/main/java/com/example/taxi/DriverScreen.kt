@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.taxi

import android.app.Activity
import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import androidx.window.layout.WindowMetricsCalculator
import com.example.taxi.ui.theme.*
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.Task

/**
 * Driver screen that displays driver-specific UI and navigation options.
 */
@Composable
fun DriverScreen(navController: NavController) {
    // 1) Measure screen width
    val context = LocalContext.current
    val windowMetrics = remember {
        WindowMetricsCalculator.getOrCreate().computeCurrentWindowMetrics(context as Activity)
    }
    val screenWidthDp = windowMetrics.bounds.width() / context.resources.displayMetrics.density

    // 2) Pick the dimension object based on screen width
    val dimens = when {
        screenWidthDp < 400f -> DriverScreenCompactSmallDimens
        screenWidthDp in 400f..500f -> DriverScreenCompactMediumDimens
        screenWidthDp in 500f..600f -> DriverScreenCompactDimens
        screenWidthDp in 600f..840f -> DriverScreenMediumDimens
        else -> DriverScreenExpandedDimens
    }

    // 3) Expose only the dimension fields that are actually used
    val smallSpacerHeight = dimens.smallSpacerHeight
    val buttonWidth = dimens.buttonWidth
    val buttonHeight = dimens.buttonHeight
    val labelTextSize = dimens.labelTextSize
    val logoImageSize = dimens.logoImageSize
    val driverImageSize = dimens.driverImageSize
    val appLogoPadding = dimens.appLogoPadding
    val appLogoSpacerHeight = dimens.appLogoSpacerHeight
    val imageSpacerHeight = dimens.imageSpacerHeight
    val imagePadding = dimens.imagePadding
    val buttonSpacerHeight = dimens.buttonSpacerHeight
    val cornerRadius = dimens.cornerRadius
    val backgroundAlpha = dimens.backgroundAlpha
    val screenPadding = dimens.screenPadding

    // 4) Get the current location once
    val location = remember { mutableStateOf<Location?>(null) }
    LaunchedEffect(Unit) {
        getCurrentLocation(context) { loc -> location.value = loc }
    }

    // 5) Build the UI
    // Use Box with windowInsetsPadding to respect system bars
    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Background image with reduced opacity
        Image(
            painter = painterResource(id = R.drawable.background_image),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = backgroundAlpha
        )

        // Gradient overlay on top of the image for better contrast
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF0A1F44).copy(alpha = 0.85f), // Dark blue at the top
                            Color(0xFF16294B).copy(alpha = 0.85f)  // Slightly lighter blue at the bottom
                        )
                    )
                )
        )

        // Main content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(screenPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(appLogoSpacerHeight))

            // App logo
            Image(
                painter = painterResource(id = R.drawable.applogo),
                contentDescription = "App Logo",
                modifier = Modifier
                    .size(logoImageSize)
                    .padding(bottom = appLogoPadding),
                contentScale = ContentScale.Fit
            )

            Spacer(modifier = Modifier.height(appLogoSpacerHeight))

            // Driver image
            Image(
                painter = painterResource(id = R.drawable.minibusd),
                contentDescription = "Minibus",
                modifier = Modifier
                    .size(driverImageSize)
                    .padding(imagePadding),
                contentScale = ContentScale.Fit
            )

            Spacer(modifier = Modifier.height(imageSpacerHeight))

            // Town Button
            Button(
                onClick = { navController.navigate("DriverMapScreenTown") },
                modifier = Modifier
                    .width(buttonWidth)
                    .height(buttonHeight),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(cornerRadius)
            ) {
                Text(text = "Town", fontSize = labelTextSize)
            }

            Spacer(modifier = Modifier.height(buttonSpacerHeight))

            // Local Button
            Button(
                onClick = { navController.navigate("DriverMapScreenLocal") },
                modifier = Modifier
                    .width(buttonWidth)
                    .height(buttonHeight),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(cornerRadius)
            ) {
                Text(text = "Local", fontSize = labelTextSize)
            }

            Spacer(modifier = Modifier.height(buttonSpacerHeight))

            // Home Button
            Button(
                onClick = { navController.navigate("home") },
                modifier = Modifier
                    .width(buttonWidth)
                    .height(buttonHeight),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(cornerRadius)
            ) {
                Text(text = "Home", fontSize = labelTextSize)
            }

            // Add a spacer at the bottom to maintain spacing
            Spacer(modifier = Modifier.height(smallSpacerHeight))
        }
    }
}

/**
 * Helper function to fetch the current location via FusedLocationProviderClient.
 */
@SuppressLint("MissingPermission")
private fun getCurrentLocation(context: Context, onLocationFetched: (Location?) -> Unit) {
    val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    fusedLocationClient.lastLocation
        .addOnCompleteListener { task: Task<Location> ->
            if (task.isSuccessful && task.result != null) {
                onLocationFetched(task.result)
            } else {
                onLocationFetched(null)
            }
        }
}

@Composable
@Preview(showBackground = true)
fun DriverScreenPreview() {
    DriverScreen(navController = rememberNavController())
}