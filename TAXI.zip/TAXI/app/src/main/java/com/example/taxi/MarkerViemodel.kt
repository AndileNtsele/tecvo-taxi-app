package com.example.taxi

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

// Data class to hold user input
data class UserLocationData(
    var destination: String = "",
    var numPeople: String = "",
    var latitude: Double = 0.0,
    var longitude: Double = 0.0
)

class UserLocationViewModel : ViewModel() {

    private val _userLocationData = MutableStateFlow(UserLocationData())
    val userLocationData: StateFlow<UserLocationData> = _userLocationData

    // Expose individual properties as state for easier observation in composables
    var destination by mutableStateOf("")
        private set
    var numPeople by mutableStateOf("")
        private set
    var latitude by mutableStateOf(0.0)
        private set
    var longitude by mutableStateOf(0.0)
        private set

    init {
        // Collect changes from the data class and update individual states
        viewModelScope.launch {
            _userLocationData.collect { data ->
                destination = data.destination
                numPeople = data.numPeople
                latitude = data.latitude
                longitude = data.longitude
            }
        }
    }


    fun updateDestination(newDestination: String) {
        _userLocationData.value = _userLocationData.value.copy(destination = newDestination)
    }

    fun updateNumPeople(newNumPeople: String) {
        _userLocationData.value = _userLocationData.value.copy(numPeople = newNumPeople)
    }

    fun updateLocation(lat: Double, long: Double) {
        _userLocationData.value = _userLocationData.value.copy(latitude = lat, longitude = long)
    }

    fun saveUserData(destination: String, numPeople: String, latitude: Double, longitude: Double) {
        viewModelScope.launch {
            _userLocationData.value = UserLocationData(
                destination = destination,
                numPeople = numPeople,
                latitude = latitude,
                longitude = longitude
            )
        }
    }
}