package com.example.taxi.models

import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.listSaver

data class Country(
    val name: String,     // e.g. "United States"
    val code: String,     // e.g. "US"
    val dialCode: String, // e.g. "+1"
    val flagEmoji: String // e.g. "🇺🇸"
) {
    companion object {
        // Use listSaver to create a Saver for the Country class
        val Saver: Saver<Country, Any> = listSaver(
            save = { country ->
                listOf(
                    country.name,
                    country.code,
                    country.dialCode,
                    country.flagEmoji
                )
            },
            restore = { items ->
                Country(
                    name = items[0] as String,
                    code = items[1] as String,
                    dialCode = items[2] as String,
                    flagEmoji = items[3] as String
                )
            }
        )
    }
}