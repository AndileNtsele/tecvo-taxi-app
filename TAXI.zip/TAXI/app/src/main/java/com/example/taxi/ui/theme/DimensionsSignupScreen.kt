// DimensionsSignupScreen.kt
package com.example.taxi.ui.theme

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Dimensions specific to the SignUpScreen.
 *
 * This data class holds all the adjustable values for component sizes,
 * spacing, and typography used in the SignUpScreen composable.
 */
data class SignUpScreenDimens(
    // Image dimensions
    val logoSize: Dp,           // Size of the app logo displayed at the top

    // Spacing
    val topSpacer: Dp,          // Spacer height at the top of the form
    val textFieldHeight: Dp,    // Height for each text field
    val textFieldPadding: Dp,   // Horizontal padding applied to text fields

    // Typography
    val labelTextSize: TextUnit, // Font size for labels and text field hints
    val loginTextSize: TextUnit, // Font size for the "Sign Up" title
    val otherTextSize: TextUnit  // Font size for other texts (e.g., button labels)
)

/*
 * Example dimension values for different screen configurations:
 *
 * 1. SignUpScreenCompactSmallDimens:
 *    - Intended for screens with width less than 400dp (very small devices).
 */
val SignUpScreenCompactSmallDimens = SignUpScreenDimens(
    logoSize = 80.dp,
    topSpacer = 16.dp,
    textFieldHeight = 48.dp,
    textFieldPadding = 16.dp,
    labelTextSize = 14.sp,
    loginTextSize = 20.sp,
    otherTextSize = 16.sp
)

/*
 * 2. SignUpScreenCompactMediumDimens:
 *    - For screens with width between 400dp and 500dp (small to medium devices).
 */
val SignUpScreenCompactMediumDimens = SignUpScreenDimens(
    logoSize = 90.dp,
    topSpacer = 18.dp,
    textFieldHeight = 50.dp,
    textFieldPadding = 18.dp,
    labelTextSize = 16.sp,
    loginTextSize = 22.sp,
    otherTextSize = 18.sp
)

/*
 * 3. SignUpScreenCompactDimens:
 *    - For screens with width between 500dp and 600dp (typical larger phones).
 */
val SignUpScreenCompactDimens = SignUpScreenDimens(
    logoSize = 100.dp,
    topSpacer = 20.dp,
    textFieldHeight = 52.dp,
    textFieldPadding = 20.dp,
    labelTextSize = 18.sp,
    loginTextSize = 24.sp,
    otherTextSize = 20.sp
)

/*
 * 4. SignUpScreenMediumDimens:
 *    - For screens with width between 600dp and 840dp (small tablets or larger phones in landscape).
 */
val SignUpScreenMediumDimens = SignUpScreenDimens(
    logoSize = 110.dp,
    topSpacer = 24.dp,
    textFieldHeight = 56.dp,
    textFieldPadding = 24.dp,
    labelTextSize = 20.sp,
    loginTextSize = 26.sp,
    otherTextSize = 22.sp
)

/*
 * 5. SignUpScreenExpandedDimens:
 *    - For screens with width greater than 840dp (larger tablets or desktop-style layouts).
 */
val SignUpScreenExpandedDimens = SignUpScreenDimens(
    logoSize = 120.dp,
    topSpacer = 28.dp,
    textFieldHeight = 60.dp,
    textFieldPadding = 28.dp,
    labelTextSize = 22.sp,
    loginTextSize = 28.sp,
    otherTextSize = 24.sp
)
