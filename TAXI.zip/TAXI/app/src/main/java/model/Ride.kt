package com.example.taxi.model

data class Ride(
    val rideId: String = "",
    val passengerId: String = "",
    val driverId: String = "",
    val origin: String = "",
    val destination: String = "",
    val status: String = "requested", // e.g., "requested", "accepted", "completed"
    val timestamp: Long = 0L
)
