package com.example.taxi.repository

import com.example.taxi.model.User
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.getValue

class FirebaseRepository {

    // Reference to the Realtime Database
    private val database: DatabaseReference = FirebaseDatabase.getInstance().reference

    /**
     * Writes a User object to the Realtime Database under the "users" node.
     *
     * @param user The User object to write.
     * @param onComplete Callback function to handle success or failure.
     */
    fun writeUser(user: User, onComplete: (Boolean, String?) -> Unit) {
        database.child("users").child(user.uid).setValue(user)
            .addOnSuccessListener {
                onComplete(true, null)
            }
            .addOnFailureListener { exception ->
                onComplete(false, exception.message)
            }
    }

    /**
     * Reads a User object from the Realtime Database based on UID.
     *
     * @param uid The unique identifier of the user.
     * @param onResult Callback function to handle the retrieved User object.
     */
    fun readUser(uid: String, onResult: (User?) -> Unit) {
        database.child("users").child(uid).get()
            .addOnSuccessListener { snapshot ->
                val user = snapshot.getValue(User::class.java)
                onResult(user)
            }
            .addOnFailureListener {
                onResult(null)
            }
    }

    /**
     * Updates a User's information in the Realtime Database.
     *
     * @param uid The unique identifier of the user.
     * @param updatedData A map containing the fields to update.
     * @param onComplete Callback function to handle success or failure.
     */
    fun updateUser(uid: String, updatedData: Map<String, Any>, onComplete: (Boolean, String?) -> Unit) {
        database.child("users").child(uid).updateChildren(updatedData)
            .addOnSuccessListener {
                onComplete(true, null)
            }
            .addOnFailureListener { exception ->
                onComplete(false, exception.message)
            }
    }

    /**
     * Deletes a User from the Realtime Database.
     *
     * @param uid The unique identifier of the user.
     * @param onComplete Callback function to handle success or failure.
     */
    fun deleteUser(uid: String, onComplete: (Boolean, String?) -> Unit) {
        database.child("users").child(uid).removeValue()
            .addOnSuccessListener {
                onComplete(true, null)
            }
            .addOnFailureListener { exception ->
                onComplete(false, exception.message)
            }
    }
}
